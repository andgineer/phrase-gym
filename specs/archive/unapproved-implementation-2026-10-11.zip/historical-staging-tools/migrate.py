"""Apply the reviewed move and first implementation with concurrent-edit guards."""
import hashlib
import json
import os
import shutil
from pathlib import Path

stage = Path(__file__).parent
work = stage / 'work'
old = Path('/Users/andrei_sorokin2/projects/phrase-shadowing')
new = Path('/Users/andrei_sorokin2/projects/phrase-gym')
baseline = json.loads((stage / 'baseline.json').read_text())
skip = {'.idea', '.git', '.venv', '__pycache__', '.pytest_cache', '.ruff_cache', 'build', 'dist', '.cache'}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def files(root):
    return [p for p in root.rglob('*') if p.is_file() and not (set(p.relative_to(root).parts) & skip)
            and p.name not in {'.coverage', 'coverage.xml', 'pytest.xml'}]

for name, root in [('new', new), ('old', old)]:
    for rel, expected in baseline[name].items():
        if not (root / rel).is_file() or digest(root / rel) != expected:
            raise SystemExit(f'Concurrent change: {root / rel}; inspect before applying')
for file in files(work):
    destination = new / file.relative_to(work)
    if destination.exists() and str(file.relative_to(work)) not in baseline['new']:
        raise SystemExit(f'Unexpected new destination: {destination}')
for folder in ('spec', 'discussion'):
    current = {str(p.relative_to(old)) for p in files(old/folder)}
    known = {p for p in baseline['old'] if p.startswith(folder + '/')}
    if current != known:
        raise SystemExit(f'Concurrent additions/removals in legacy {folder}')

# Apply all new project contents and verify them before removing the old docs.
for file in files(work):
    destination = new / file.relative_to(work)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if file.is_symlink():
        destination.symlink_to(os.readlink(file))
    else:
        shutil.copy2(file, destination)
for file in files(work):
    assert digest(file) == digest(new / file.relative_to(work)), file

# Move source directories to a recoverable task backup only after the new copies
# are verified. The new spec is the active home; the backup is not a second workspace.
archive = stage / 'moved-originals'
archive.mkdir(exist_ok=False)
for folder in ('spec', 'discussion'):
    shutil.move(str(old / folder), str(archive / folder))

# Remove only the new-app framing from the legacy README, retaining its source
# format/tooling updates. The pre-move version is preserved in spec/history/.
readme = (old / 'README.md').read_text()
readme = readme.replace('# phrase-shadowing — Phrase Gym workspace', '# phrase-shadowing')
lines = readme.splitlines()
lines = [line for line in lines if not line.startswith('This README describes legacy source tooling')]
readme = '\n'.join(lines).replace('\n\n\n', '\n\n') + '\n'
readme = readme.replace('- Legacy published-page reference: https://claude.ai/artifact/Jwe4YpVMthy8UjerkdEKY2 (current state not inspected; no progress migration assumed)',
                       '- Published page: https://claude.ai/artifact/Jwe4YpVMthy8UjerkdEKY2 (progress lives in the artifact\'s `db`, per user)')
(old / 'README.md').write_text(readme)
(old / 'CLAUDE.md').write_text('''# phrase-shadowing — legacy trainer

`AGENTS.md` is a symlink to this file.

This directory contains the original “Английское эхо” trainer and source tooling. Read `README.md` for the lesson format and fetch/split/TTS/build commands. Preserve `index.html`, `phrases.py` and the existing published trainer unless the user specifically requests changes.

- Reply in English. Keep learning material in its target language; translations are on request.
- Source notes are under `~/obsidian/kb/languages/english/фразы/`, with audio in `_assets/`. Code and generated output belong under `~/projects/` or a task scratch directory, not in the vault.
- The vault is synced by obsidian-git. Do not commit, push, switch branches or use `git mv` there.
- This folder has no Git metadata; do not initialize or commit unless requested.
- Enrollment in additional course lessons and republishing are separate actions requiring the user's request.
''')
assert (old/'AGENTS.md').is_symlink()
for name in ('index.html', 'phrases.py'):
    assert digest(old/name) == baseline['old'][name]
assert digest(new/'spec/decision-targeted-drilling.md') == baseline['old']['spec/decision-targeted-drilling.md']
assert digest(new/'spec/research-memorizing-phrases.md') == baseline['old']['spec/research-memorizing-phrases.md']
assert digest(new/'spec/history/discussion/session-2026-10-08-to-10.zip') == baseline['old']['discussion/session-2026-10-08-to-10.zip']
print(f'Installed {len(files(work))} project files; old trainer code and accepted decisions unchanged.')
print(f'Recoverable pre-move backup: {stage}')

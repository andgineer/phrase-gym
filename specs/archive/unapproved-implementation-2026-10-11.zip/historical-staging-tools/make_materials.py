"""Author the disposable P1 pack; not a runtime material generator."""
import json
from pathlib import Path

root = Path(__file__).parent / "work"
targets = []


def target(key, kind, title, purpose, meaning, chunks, required, cues, allowed=(), slots="No substitutions in this fixed expression."):
    targets.append({
        "id": key, "revision": 1, "language": "en", "kind": kind,
        "title": title, "purpose": purpose, "meaning": meaning,
        "full_text": " ".join(chunks),
        "chunks": [{"id": f"c{i+1}", "text": text} for i, text in enumerate(chunks)],
        "required_chunks": required, "allowed_variants": list(allowed), "slots": slots,
        "audio": {"status": "pending", "source": "Record or import a checked model of this exact realization during P1.3; no synthetic stand-in is played."},
        "cues": [{"id": f"{key}-{i+1}", "visible_chunks": visible, "task": task,
                  "evidence": evidence, "rationale": why, "competitors": competitors,
                  "review_status": "author_checked"}
                 for i, (visible, task, evidence, why, competitors) in enumerate(cues)],
    })


target("day", "fixed", "A colleague's day", "Ask about your colleague's day up to now.",
       "A friendly question before the working day has ended.",
       ["How has", "your day", "been so far?"], ["c1", "c2", "c3"], [
    (["c2", "c3"], "Recall the day-so-far question you learned. Say the whole question.", "partial_phrase",
     "The present-perfect ending and day identify the learned question; the whole opening is retrieved.",
     ["How is your day going? changes the visible ending.", "How was your day? changes both tense and the visible ending."]),
    (["c1", "c3"], "Ask about the listener's day, using the question you learned. Say the whole question.", "partial_phrase",
     "The time span and explicit listener's day distinguish the missing subject from week or meeting.",
     ["How has your week been so far? does not match the requested day."])
])
target("meet", "fixed", "Meeting face to face", "Greet a colleague you have previously met only online.",
       "Warmly mark the first meeting in person.", ["It's great", "to finally meet you", "in person."], ["c1", "c2", "c3"], [
    (["c1", "c3"], "Recall the first-meeting greeting you learned. Say the whole greeting.", "partial_phrase",
     "The evaluation and in-person anchor constrain the learned greeting; finally belongs to the recalled chunk.",
     ["It's great to see you in person is natural: use Different wording if that is what came to mind."]),
    (["c2", "c3"], "Recall the same warm first-meeting greeting. Say the whole greeting.", "partial_phrase",
     "The full first-meeting complement identifies this target within the pack; the evaluation is recalled.",
     ["It's lovely to finally meet you in person is valid English, but different learned wording."])
], ["It is great to finally meet you in person."])
target("point", "fixed", "Acknowledging an argument", "A colleague suggests allowing more time for testing. Acknowledge the merit of that point.",
       "Recognize that an argument is useful or reasonable.", ["That's", "a good", "point."], ["c1", "c2", "c3"], [
    (["c2", "c3"], "Recall the short acknowledgement you learned. Say the complete sentence.", "partial_phrase",
     "The noun phrase anchors the learned acknowledgement rather than an unrelated agreement formula.",
     ["That's a fair point changes the visible adjective.", "You've made a good point is natural alternative wording."]),
    (["c1", "c2"], "Recall the acknowledgement meaning 'that is a useful argument'. Say the complete sentence.", "partial_phrase",
     "Retaining a good avoids guessing between good and fair; the useful-argument meaning identifies point rather than idea.",
     ["That's a good idea evaluates a proposed action rather than the argument specified here."])
], ["That is a good point."])
target("moment", "fixed", "Time to consider", "Someone asks for your decision. Politely ask for a short thinking pause.",
       "Request a moment before answering.", ["Could you", "give me a moment", "to think about it?"], ["c1", "c2", "c3"], [
    (["c2", "c3"], "Recall the polite question you learned, using could. Say the whole question.", "partial_phrase",
     "The body fixes the request; could in the instruction disambiguates the modal. This is supported practice.",
     ["Can you give me a moment to think about it? is natural, but the task explicitly supplies could."]),
    (["c1", "c2"], "Recall the same request for time to think about the decision. Say the whole question.", "partial_phrase",
     "The intact request anchors the target and the purpose identifies the thinking complement.",
     ["Could you give me a moment to check? changes the stated purpose."])
])
target("mean", "fixed", "Checking a meaning", "Your colleague says the proposal needs to be more flexible. Ask them to clarify that statement.",
       "Ask precisely what the other person intends by a statement.", ["What exactly", "do you mean", "by that?"], ["c1", "c2", "c3"], [
    (["c1", "c3"], "Recall the clarification question you learned. Say the whole question.", "partial_phrase",
     "Exactly and by that identify the clarification pattern in the learned set.",
     ["What exactly are you suggesting by that? is possible but is a different question."]),
    (["c2", "c3"], "Recall the same clarification question, including its precision word. Say the whole question.", "partial_phrase",
     "The retained question body plus precision purpose prompts What exactly rather than How.",
     ["What do you mean by that? omits the learned precision word."])
])
target("understand", "fixed", "Checking your understanding", "Confirm that your colleague means the team needs more time.",
       "Tentatively restate what you understood and invite correction.",
       ["If I understand you correctly,", "you're saying that", "we need more time."], ["c1", "c2", "c3"], [
    (["c1", "c3"], "Recall the complete restatement you learned. Say the whole sentence.", "partial_phrase",
     "Both the tentative opening and concrete message remain; the linking chunk is retrieved.",
     ["If I understand you correctly, we need more time is shorter valid wording; it omits the target link."]),
    (["c2", "c3"], "Recall the same restatement, including the tentative 'if' opening. Say the whole sentence.", "partial_phrase",
     "The intact restatement plus the if hint identify the long opening in this pack.",
     ["As I understand it, you're saying that we need more time is natural but uses a different opening."])
], ["If I understand you correctly, you are saying that we need more time."])
target("postpone", "word", "Moving a meeting", "The team cannot meet today. Say that the meeting needs to move to a later time.",
       "postpone: arrange for something planned to happen later.", ["We need to", "postpone", "the meeting."], ["c2"], [
    (["c1", "c3"], "Use the verb you learned meaning 'move a planned event to a later time'. Say the whole sentence.", "target_recall",
     "The learned sense and complete sentence frame specify the task; delay is still a valid alternative to report.",
     ["We need to delay the meeting is valid English. Different wording records it without a memory failure."]),
    (["c2", "c3"], "Say what we need to do, using the shown verb. Say the whole sentence you learned.", "usage",
     "The word is visible: this practises its use and cannot establish retrieval of postpone.",
     ["We should postpone the meeting is appropriate but changes the selected need-to frame."])
], ["We need to postpone our meeting."], "Use postpone in the selected sense. The meeting / our meeting are allowed here; a later controlled example may change the event.")
target("available", "word", "Checking a colleague's time", "Ask whether your colleague has time for a brief call.",
       "available: free to do something at a particular time.", ["Are you", "available", "for a quick call?"], ["c2"], [
    (["c1", "c3"], "Use the adjective you learned meaning 'free to do something'. Say the whole question.", "target_recall",
     "The selected learned adjective is the target; free is natural competing wording and is handled explicitly.",
     ["Are you free for a quick call? is natural English but does not retrieve available."]),
    (["c1", "c2"], "Ask about a brief call using the shown adjective. Say the complete question.", "usage",
     "Available stays visible; the learner completes its complement, practising use only.",
     ["Are you available for a short call? is an allowed realization."])
], ["Are you available for a short call?"], "Keep the adjective available in the free-to-do-something sense; quick/short call are both allowed.")
target("compromise", "word", "Finding an agreement", "Both sides must give up something to reach agreement. Suggest the next step.",
       "compromise: an agreement in which each side accepts less than it initially wanted.", ["Let's find", "a compromise", "that works for both sides."], ["c2"], [
    (["c1", "c3"], "Use the noun you learned for an agreement involving concessions. Say the whole sentence.", "target_recall",
     "The concessions meaning distinguishes compromise from any agreement, without showing the noun.",
     ["Let's find a solution that works for both sides is broader and does not specify concessions."]),
    (["c1", "c2"], "Complete the suggestion so the agreement is suitable for both sides. Say the whole sentence.", "usage",
     "The noun is visible; only the surrounding use is practised.",
     ["Let's find a compromise that suits both sides is allowed."])
], ["Let's find a compromise that suits both sides."], "Keep compromise as an agreement noun; that works for / that suits both sides are allowed.")
target("mind", "frame", "Requesting the figures", "Politely ask your colleague to send you the updated figures.",
       "Would you mind + -ing: a polite request to do something.", ["Would you mind", "sending me", "the updated figures?"], ["c1", "c2"], [
    (["c1", "c3"], "Complete the polite request with the action of sending the figures to you. Say the whole question.", "usage",
     "The construction opening is visible; producing the -ing action practises use, not recall of the whole construction.",
     ["Would you mind to send me ... does not fit this construction."]),
    (["c2", "c3"], "Recall the polite request you learned whose opening asks whether the action would bother the listener. Say the whole question.", "usage",
     "The -ing chunk and bother meaning anchor Would you mind; part of the construction remains shown.",
     ["Could you sending me ... is ungrammatical; Would you consider sending me ... changes the request nuance."])
], [], "Frame: Would you mind + verb-ing. This scene asks for sending me the updated figures; other actions belong to later controlled scenes.")
target("forward", "frame", "Welcoming a collaboration", "Tell your new colleague that you anticipate working together with pleasure.",
       "look forward to + noun/-ing: anticipate something with pleasure.", ["I'm", "looking forward to", "working with you."], ["c2"], [
    (["c1", "c3"], "Recall the anticipation expression you learned. Say the whole sentence.", "target_recall",
     "The -ing complement and learned meaning cue the selected construction without displaying it.",
     ["I'm excited about working with you is natural alternative wording, not evidence of forgetting."]),
    (["c1", "c2"], "Complete the learned expression with the activity of working together. Say the whole sentence.", "usage",
     "The target construction is shown; the -ing complement is practised.",
     ["I'm looking forward to work with you uses an infinitive where this frame needs -ing."])
], ["I am looking forward to working with you."], "Keep look forward to + -ing; I'm/I am are equivalent. Other activities need their own scene.")
target("used", "frame", "A familiar working routine", "Explain that working remotely is already familiar and normal for you.",
       "be used to + noun/-ing: be accustomed to something (not a past habit with used to + infinitive).",
       ["I'm", "used to", "working remotely."], ["c2"], [
    (["c1", "c3"], "Recall the expression you learned meaning 'accustomed to', not a past habit. Say the whole sentence.", "target_recall",
     "The semantic distinction and -ing complement select be used to in the learned set.",
     ["I'm comfortable working remotely is natural but different wording.", "I used to work remotely describes a past habit instead."]),
    (["c1", "c2"], "Complete the familiar-routine expression with working remotely. Say the whole sentence.", "usage",
     "The target is displayed; forming the -ing complement is usage practice only.",
     ["I'm used to work remotely confuses the accustomed-to frame with the past-habit pattern."])
], ["I am used to working remotely."], "Keep be used to + -ing. I'm/I am are equivalent; the current action is working remotely.")

dialogues = [
    {"id": "first-meeting", "title": "Before the first meeting", "learner_role": "You",
     "purpose": "Meet an online colleague in person and start a friendly exchange.", "turns": [
        {"speaker": "Alex", "text": "Hi! It's good to be here at last."},
        {"speaker": "You", "target_id": "meet", "cue_id": "meet-1"},
        {"speaker": "Alex", "text": "Yes, it's been a busy morning."},
        {"speaker": "You", "target_id": "day", "cue_id": "day-1"},
        {"speaker": "Alex", "text": "Pretty well, thanks. Shall we grab a coffee?"},
        {"speaker": "You", "text": "Yes, that sounds good."},
    ]},
    {"id": "project-timing", "title": "Agreeing on project timing", "learner_role": "You",
     "purpose": "Clarify a concern and give yourself time to consider the schedule.", "turns": [
        {"speaker": "Alex", "text": "I think the schedule needs to be more flexible."},
        {"speaker": "You", "target_id": "mean", "cue_id": "mean-1"},
        {"speaker": "Alex", "text": "We need another week for testing."},
        {"speaker": "You", "target_id": "point", "cue_id": "point-1"},
        {"speaker": "Alex", "text": "Can we agree on the revised dates now?"},
        {"speaker": "You", "target_id": "moment", "cue_id": "moment-1"},
        {"speaker": "Alex", "text": "Of course. Take your time."},
    ]},
]
rejections = [
    {"id": "broad-question", "reason": "A purpose alone cannot demand one exact phrase.", "prompt": "Ask about his day.", "competing_answers": ["How was your day?", "How has your day been so far?"], "resolution": "Introduce a specific expression and show phrase-specific material."},
    {"id": "visible-word-credit", "reason": "A displayed word cannot count as recalling that word.", "prompt": "We need to postpone ____.", "resolution": "Classify as usage, as in postpone-2; never give lexical-recall credit."},
    {"id": "unintroduced", "reason": "An unfamiliar expression is a guessing task, not retrieval.", "prompt": "Retrieve Let's touch base without seeing it first.", "resolution": "Require introduction before recall; this target is deliberately absent from the queue."},
    {"id": "ambiguous-opening", "reason": "Mechanical beginning-only masking leaves too many natural completions.", "prompt": "Could you ____?", "competing_answers": ["help me?", "give me a moment?", "repeat that?"], "resolution": "Retain the phrase-specific body, as in moment-1."},
    {"id": "letters", "reason": "First-letter puzzles are outside the agreed design.", "prompt": "H h y d b s f?", "resolution": "Show meaningful chunks, as in day-1 and day-2."},
]
pack = {"schema_version": 1, "id": "p1-english-v1", "revision": 1,
        "review": {"status": "author_checked", "reviewer": "Codex; learner review pending", "date": "2026-10-11",
                   "limits": "Manual author cue/competitor check only. No independent human review, model audio or efficacy validation. Not for production publication."},
        "targets": targets, "dialogues": dialogues, "rejected_candidates": rejections}
path = root / "fixtures/p1/materials.json"
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(pack, ensure_ascii=False, indent=2) + "\n")
sheet = ["# P1 cue review sheet", "", "Author check: Codex, 2026-10-11. Learner review and audio checks are pending. These are prototype examples, not published teaching material.", "",
         "Every cue requests a previously introduced expression and a complete spoken sentence. Competitors below explain the remaining uncertainty. Different wording and Unclear cue are always available; neither automatically means a memory failure.", "",
         "The targets and cues live in [the versioned fixture pack](../../fixtures/p1/materials.json). Audio is explicitly pending for every realization; the first flow prototype is text-only. No browser TTS is substituted.", ""]
for t in targets:
    sheet += [f"## {t['id']} — {t['full_text']}", "", t['purpose'], "", f"Allowed use: {t['slots']}", ""]
    for c in t['cues']:
        mask = " ".join(x['text'] if x['id'] in c['visible_chunks'] else "[…]" for x in t['chunks'])
        sheet += [f"- **{c['id']}**: {mask} — `{c['evidence']}`. {c['rationale']}"]
        sheet += ["  - " + item for item in c['competitors']]
    sheet += [""]
sheet += ["## Review checklist", "", "The pack includes a long expression (understand), contractions (meet/point), -ing frames (mind/forward/used), three lexical senses, visible-word usage cues, and rejection fixtures for broad prompts, guessing and arbitrary masks. No claim of uniqueness across English is made. Some masks still invite natural alternatives; the walkthrough must establish whether the initial identifying material is sufficient for this learner.", ""]
(root / "spec/design/p1-cue-review.md").write_text("\n".join(sheet))
print(f"Wrote {len(targets)} targets, {len(dialogues)} dialogues and {len(rejections)} rejections")

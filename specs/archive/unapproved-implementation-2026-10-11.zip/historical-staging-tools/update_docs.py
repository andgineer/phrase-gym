from pathlib import Path
import json

root = Path(__file__).parent / 'work'

def replace(path, old, new):
    file = root / path
    text = file.read_text()
    assert text.count(old) == 1, (path, old)
    file.write_text(text.replace(old, new))

replace('spec/plan/implementation-plan.md',
        'Created 2026-10-11. **Planning only. No Phrase Gym prototype or production implementation exists. All phases below are not started.** Earlier sketches and legacy files do not satisfy any milestone.',
        'Updated 2026-10-11. **P1 is in progress in `~/projects/phrase-gym`: an author-checked fixture pack and a runnable text-only interaction prototype are available for review. P2–P6 are not started.** Earlier sketches and legacy files do not satisfy any milestone. See the [P1 implementation evidence](evidence/p1-first-slice.md).')
replace('spec/plan/implementation-plan.md', 'There are no completed reports yet.', 'The [first P1 report](evidence/p1-first-slice.md) records the initial implementation and its remaining checks.')
replace('spec/plan/implementation-plan.md', '## First implementation task\n\nStart **P1.1: prepare the small reviewed content and cue set**. Then build the interaction prototype and a real audio probe. Do not start from the earlier screen layouts as an approved design, and do not skip prototyping to scaffold the production application.',
        '## Current implementation and next work\n\nThe user created a Python package scaffold in `~/projects/phrase-gym` and authorized implementation on 2026-10-11. Preserve its `src/phrase_gym`, hatchling/uv packaging, Click entry point, pytest, Invoke and documentation/build workflows. The template file-conversion CLI is replaced with material validation and a localhost prototype launcher. `spec/` is the home of all development documentation; `docs/` remains the scaffold’s user-documentation site.\n\nRun `uv run phrase-gym prototype` from this checkout. The disposable browser client uses plain JavaScript and localStorage; these are P1 tools, not a change to the proposed production stack. Next: review the cue examples and seven walkthroughs, refine any confusing cues, then build P1.3’s real-device audio/storage probe. P1.4 still precedes production foundation work.')
replace('spec/plan/01-prototyping.md', 'Status: **not started**, 2026-10-11.', 'Status: **in progress**, 2026-10-11. P1.1 and P1.2 have a first implementation; learner review and acceptance remain pending. P1.3 and P1.4 are not started. See [evidence](evidence/p1-first-slice.md).')
replace('spec/functional-description.md', 'there is no Phrase Gym prototype or implementation.', 'the first text-only prototype is available for review, with no production implementation yet.')
replace('spec/functional-description.md', 'The next implementation phase is [prototyping](plan/01-prototyping.md).', 'The current implementation phase is [prototyping](plan/01-prototyping.md).')
replace('spec/design/interaction-design.md', '**No app prototype or approved interaction design exists.**', '**The first text-only prototype exists for review; its interaction design is not yet approved.** See [P1 implementation evidence](../plan/evidence/p1-first-slice.md) and run `uv run phrase-gym prototype` from the new checkout.')
replace('spec/design/interaction-design.md', 'The output of this work will be a runnable prototype, recorded user feedback, actual-device findings and revised design decisions.', 'The runnable first slice covers text interactions and local checkpoints. Recorded user feedback, audio/device findings and revised design decisions are still required.')
replace('spec/decision-name-and-design.md', 'The project directory remains `phrase-shadowing`.', 'On 2026-10-11 the user moved the new app into `~/projects/phrase-gym`, using their Python package scaffold. Development documentation lives in its `spec/` folder; phrase-shadowing retains the old trainer and tooling.')
replace('spec/decision-name-and-design.md', 'There is no Phrase Gym prototype or implementation baseline.', 'At that point there was no Phrase Gym prototype or implementation baseline. The first P1 text prototype has since been implemented for review; it is not an approved design or production milestone.')
replace('spec/plan/functionality-discussion.md', '- **Clarified by the user:** no Phrase Gym prototype exists. Prototyping is future work, not a completed milestone based on earlier sketches or legacy files.', '- **Baseline clarification:** before implementation, no Phrase Gym prototype existed. Earlier sketches and legacy files do not count as completed milestones.')
replace('spec/plan/functionality-discussion.md', '- **Current work:** architecture and implementation planning. All implementation phases are not started.', '- **Current work:** implementation authorized in the new `~/projects/phrase-gym` scaffold. P1 has a text-only prototype and fixture pack for review; P2–P6 are not started. See [first implementation evidence](evidence/p1-first-slice.md).')
replace('spec/architecture.md', 'prototypes/drill-flow/         disposable interaction prototype, to be created', 'prototypes/drill-flow/         first disposable text interaction prototype')
replace('spec/architecture.md', 'This is a proposed layout, not existing scaffolding. Existing `index.html` and `phrases.py` are outside the new application boundary. Their presence is not a completed prototype milestone.',
        'The user-created Python scaffold in `~/projects/phrase-gym` is the implementation starting point. Retain its src layout, hatchling/uv packaging, Click entry point, pytest, Invoke, CI and documentation tooling. `main.py` now exposes P1 material validation and the local prototype launcher; the listed production modules remain future work. The disposable P1 client uses plain JavaScript and localStorage, without production scheduling or APIs. Existing `index.html` and `phrases.py` remain in `../phrase-shadowing/` outside this application boundary.')
# Archived root documents are historical data, never live agent policy. Retain their
# text and fix only links whose base moved with the documents.
replace('spec/history/phrase-shadowing-README.md', '(spec/decision-targeted-drilling.md)', '(../decision-targeted-drilling.md)')
replace('spec/history/phrase-shadowing-README.md', '(spec/architecture.md)', '(../architecture.md)')
replace('spec/history/phrase-shadowing-README.md', '(spec/plan/implementation-plan.md)', '(../plan/implementation-plan.md)')
replace('pyproject.toml', 'keywords = [ "one", "two", ]', 'keywords = [ "language-learning", "phrases", "retrieval-practice", ]')
replace('src/phrase_gym/__init__.py', '"""A language trainer for automatic use of words and phrases through guided recall, spaced repetition, and targeted dialogue drills.\n\nThe file is mandatory for build system to find the package.\n"""', '"""Phrase Gym: targeted word, phrase and prepared-dialogue drills."""')
replace('docs/mkdocs.yml', 'site_name: phrase_gym', 'site_name: Phrase Gym')
replace('docs/mkdocs.yml', 'repo_name: phrase_gym', 'repo_name: phrase-gym')

(root/'spec/agent-guide.md').write_text('''# Phrase Gym — development instructions

The user has authorized implementation in `~/projects/phrase-gym`, using the scaffold they created. The learning baseline is [targeted drilling](decision-targeted-drilling.md). Follow the [roadmap](plan/implementation-plan.md) and the current [P1 report](plan/evidence/p1-first-slice.md). Read the applicable phase and architecture documents before changing their contracts.

- Reply and write project development documents in English. Learning material stays in its target language; translations are on request.
- Preserve the scaffold: `src/phrase_gym`, hatchling, uv, rich-click, pytest, Invoke, CI and documentation workflows. Replace templates with working Phrase Gym behaviour.
- P1 is prototyping, not the production foundation. The first text-only walkthrough and author-checked pack require learner review. Audio/device checks and the P1.4 decision remain pending. Proposed stack and scheduling parameters are not accepted merely because a document recommends them.
- Train selected words, constructions, fixed expressions and prepared dialogues. Open-ended AI conversation and free role-play are excluded entirely.
- Introduce expressions before recall; use sufficient phrase-specific meaningful anchors and deliberately varied masks. Require the whole phrase aloud. Do not punish valid alternative language or ambiguous prompts.
- Record support used. Model reading, immediate repair, partial-cue recall and shown-word usage are distinct evidence. Keep one target identity across cues and dialogue appearances.
- All development docs, decisions, research and evidence belong under `spec/`. `docs/` is the existing user-documentation site. `spec/history/` is archival data, not current instructions.
- Run Python tests, the prototype reducer tests, lint/type checks and relevant browser walkthroughs after behaviour changes. `uv run inv test` runs the Python and JavaScript suites. `uv run inv pre` uses pre-commit once Git is initialized; do not initialize Git just to run it. Record equivalent direct checks and any limitation while this directory has no Git metadata.
- Do not initialize Git, commit, publish, enroll in courses or switch echo-words output unless requested. The vault is read-only source material for this project; write code and generated state outside it.
- `../phrase-shadowing/` contains the old trainer; it is neither a Phrase Gym prototype nor progress to migrate. Its README documents the original source format. Follow echo-words' own instructions if that separate project is changed later.

Read [architecture](architecture.md), [learning engine](architecture/learning-engine.md), [data contracts](architecture/data-contracts.md), [cue review](design/p1-cue-review.md) and [research limits](research-memorizing-phrases.md) as needed. No research result certifies this complete workflow or AI-generated content.
''')
(root/'CLAUDE.md').write_text('''# Phrase Gym

Read and follow [spec/agent-guide.md](spec/agent-guide.md) for project instructions and current implementation status. Development documentation lives under `spec/`.
''')
(root/'AGENTS.md').symlink_to('CLAUDE.md')
(root/'spec/README.md').write_text('''# Phrase Gym development

The app lives in `~/projects/phrase-gym`, using the user's Python package scaffold. The old phrase-shadowing trainer remains a separate project.

- [Accepted drilling behaviour](decision-targeted-drilling.md)
- [Name and project baseline](decision-name-and-design.md)
- [Implementation roadmap](plan/implementation-plan.md) and [P1 status/evidence](plan/evidence/p1-first-slice.md)
- [Architecture](architecture.md), [learning engine](architecture/learning-engine.md), [data contracts](architecture/data-contracts.md)
- [Prototype walkthrough guide](design/p1-walkthrough.md) and [cue review](design/p1-cue-review.md)
- [Research and its limits](research-memorizing-phrases.md)
- [Open product choices](plan/functionality-discussion.md)
- [Development instructions](agent-guide.md)
- [Migration record](plan/evidence/project-move.md)

`history/` contains archived source documents and the original discussion export. They are historical evidence, not the current specification or instructions.
''')
(root/'README.md').write_text('''# Phrase Gym

A language trainer for automatic use of words and phrases through guided recall, spaced repetition, and targeted dialogue drills.

Development is at **P1: prototyping**. The current runnable slice is a text-only walkthrough with 12 learning targets, 24 reviewed-by-author cue candidates and two prepared dialogues. Say complete phrases aloud and compare them with the model. No audio, speech assessment, due-review scheduling or production progress storage is implemented yet.

## Try the prototype

Requires Python 3.12+ and uv. Run from this checkout:

```bash
uv sync --locked
uv run phrase-gym validate-materials
uv run phrase-gym prototype
```

Open [the local prototype](http://127.0.0.1:8765). Use `--port` to choose another local port, or `--project-dir` when running outside the checkout. Ctrl+C stops the server. The server exposes only the prototype assets and fixture pack.

The walkthrough saves a temporary checkpoint in this browser, including help already shown. It does not create real learning progress. Choose “Clear this browser's walkthrough” to remove it. Recordings are not collected.

## Development

Keep the existing Python src layout, hatchling/uv packaging, Click command, pytest, Invoke and documentation tooling. Disposable browser code is under `prototypes/drill-flow/`; fixtures are under `fixtures/p1/`. The eventual production stack remains a proposal to validate.

```bash
uv run inv test              # Python plus prototype JavaScript tests; needs Node 20+
uv run inv pre               # pre-commit checks once this checkout has Git metadata
uv run inv build-docs        # existing documentation build
uv run phrase-gym --help
```

All development decisions, architecture, plans and evidence live in [spec/](spec/README.md). Start with the [roadmap](spec/plan/implementation-plan.md) and [prototype walkthrough](spec/design/p1-walkthrough.md). `docs/` is the scaffold's user-documentation site. No package release or hosted app is implied by the scaffold's publishing workflows.
''')
for language in ['en', 'ru']:
    (root/f'docs/src/{language}/index.md').write_text('''# Phrase Gym

Targeted practice for words, phrases and prepared dialogues.

The project is at P1 prototyping. The text-only local walkthrough introduces a model, presents a phrase-specific cue, asks for the whole phrase aloud and supports self-comparison and repair. It includes 12 targets and two dialogues. Audio, recording, scheduling and the production app are not implemented yet.

Run `uv run phrase-gym prototype` from the source checkout, then open `http://127.0.0.1:8765`. Temporary walkthrough state stays in the browser and can be cleared from the start screen.

See `spec/` in the source checkout for the accepted decisions, architecture and implementation plan. Use `uv run phrase-gym --help` for available development commands.
''')
    (root/f'docs/src/{language}/installation.md').write_text('''# Run from source

The first prototype requires the source checkout, Python 3.12+ and uv. No published package or hosted application is assumed.

From the Phrase Gym project directory:

```bash
uv sync --locked
uv run phrase-gym validate-materials
uv run phrase-gym prototype
```

Open `http://127.0.0.1:8765`. Stop the server with Ctrl+C. The prototype is served on localhost only; real phone/HTTPS testing is a later P1 task.

For checks, run `uv run inv test` (requires Node 20+ as well as Python). Development documentation is in the project's `spec/` folder.
''')
(root/'spec/design/p1-walkthrough.md').write_text('''# First prototype walkthrough

Run `uv run phrase-gym prototype` from the project root and open `http://127.0.0.1:8765`. These are review scenarios, not completed usability findings. Audio is explicitly absent in this first slice; read the model and say your response aloud.

1. **New phrase:** choose First phrases with the familiar-expression checkbox off. Read “How has your day been so far?”, its meaning and purpose. Say it, press Hide the model and try, then say the complete question from the partial cue. Press I've said it — compare and report your result. The first result remains model-assisted.
2. **Known phrase / changed cue:** on the home screen, mark that you have already learned the set. Start First phrases and respond to each cue. After two other targets, the day question returns with another meaningful part hidden. If an expression is unfamiliar, choose I haven't learned this yet.
3. **Help / repair:** choose Show one more chunk or Show the model and practise. Say the complete phrase; continue. A model-assisted response remains labelled as such. A difficult target returns after intervening items where available, with at most two added retries.
4. **Word / construction:** choose Words in phrases or Reusable patterns. Compare the first cue with the next version. When the target itself is shown, the result is usage practice, never lexical recall. Allowed contractions, complements and substitutions appear with the model.
5. **Alternative / unclear cue:** after saying your response, compare and choose I used different wording or The cue was unclear. Continue. Results preserve the report and do not infer forgetting or automatically retry a defective cue.
6. **Specific dialogue:** choose Read and rehearse. Read both sides and say your side before starting. Partner and supporting lines stay readable. On a target turn choose I struggled, practise that line in isolation, and return to the same exchange with the partner line. The preview and same-session retry remain distinct from delayed recall.
7. **Pause / reload:** ask for help, pause, then reload. Resume from the start screen. The same step and help remain recorded. Storage errors produce a warning; the app does not claim the step was saved when the browser rejects it.

At the end, check that results group all cue versions and dialogue attempts under the same learning target. There are no due dates, scores or claims of independent fluency.

Review questions: Was the requested expression identifiable from its initial cue? Did you know what complete response to say and when to compare? Did the model/support labels describe what happened? Which cue should be strengthened or allowed to accept more wording? Record the user's actual answers in P1 evidence; do not infer approval from this guide.
''')

# These are real observed toolchain changes: the user scaffold's lock did not match
# its declared dependencies. uv lock reconciles it without requesting --upgrade.
replace('tasks.py', '@task\ndef pre(c):', '@task\ndef test(c):\n    """Run Python tests and the disposable prototype reducer tests (Node 20+)."""\n    c.run("python -m pytest tests/ --cov=phrase_gym --cov-report=term-missing")\n    c.run("node --test tests/prototype/engine.test.mjs")\n\n\n@task\ndef pre(c):')
workflow=root/'.github/workflows/ci.yml'
text=workflow.read_text()
text += '''
  prototype-checks:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-node@v4
      with:
        node-version: '20'
    - name: Check prototype session behaviour
      run: node --test tests/prototype/engine.test.mjs
'''
workflow.write_text(text)
print('Updated current docs, scaffold templates, Invoke and CI')

# Phrase Gym

Read and follow [spec/agent-guide.md](spec/agent-guide.md) for project instructions and current implementation status. Development documentation lives under `spec/`.

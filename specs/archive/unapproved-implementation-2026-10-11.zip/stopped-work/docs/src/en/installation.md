# Run from source

The first prototype requires the source checkout, Python 3.12+ and uv. No published package or hosted application is assumed.

From the Phrase Gym project directory:

```bash
uv sync --locked
uv run phrase-gym validate-materials
uv run phrase-gym prototype
```

Open `http://127.0.0.1:8765`. Stop the server with Ctrl+C. The prototype is served on localhost only; real phone/HTTPS testing is a later P1 task.

For checks, run `uv run inv test` (requires Node 20+ as well as Python). Development documentation is in the project's `spec/` folder.

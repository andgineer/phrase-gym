# Phrase Gym

Targeted practice for words, phrases and prepared dialogues.

The project is at P1 prototyping. The text-only local walkthrough introduces a model, presents a phrase-specific cue, asks for the whole phrase aloud and supports self-comparison and repair. It includes 12 targets and two dialogues. Audio, recording, scheduling and the production app are not implemented yet.

Run `uv run phrase-gym prototype` from the source checkout, then open `http://127.0.0.1:8765`. Temporary walkthrough state stays in the browser and can be cleared from the start screen.

See `spec/` in the source checkout for the accepted decisions, architecture and implementation plan. Use `uv run phrase-gym --help` for available development commands.

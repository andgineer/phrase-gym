"""Development commands for the first Phrase Gym prototypes."""

from pathlib import Path

import rich_click as click

from phrase_gym import __version__
from phrase_gym.materials import load_materials
from phrase_gym.prototype import find_project, serve_prototype

click.rich_click.USE_MARKDOWN = True


@click.group()
@click.version_option(version=__version__, prog_name="phrase-gym")
def phrase_gym() -> None:
    """Phrase Gym: validate drill material and try the local P1 prototype."""


@phrase_gym.command("validate-materials")
@click.argument(
    "pack",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    required=False,
)
def validate_materials(pack: Path | None) -> None:
    """Check a prototype JSON PACK (defaults to fixtures/p1/materials.json)."""
    try:
        source = pack if pack is not None else find_project() / "fixtures/p1/materials.json"
        material = load_materials(source)
    except (OSError, ValueError) as error:
        raise click.ClickException(str(error)) from error
    click.echo(
        f"Valid prototype pack: {len(material['targets'])} targets, "
        f"{sum(len(t['cues']) for t in material['targets'])} cues, "
        f"{len(material['dialogues'])} dialogues.",
    )
    click.echo("Structural checks only; learner review and model audio are still required.")


@phrase_gym.command("prototype")
@click.option("--port", default=8765, show_default=True, type=click.IntRange(1024, 65535))
@click.option("--project-dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
def prototype(port: int, project_dir: Path | None) -> None:
    """Serve the disposable drill flow on localhost; requires this source checkout."""
    try:
        root = find_project(project_dir)
        load_materials(root / "fixtures/p1/materials.json")
        click.echo(f"Phrase Gym prototype: http://127.0.0.1:{port}")
        click.echo("Text-only P1 walkthrough. Press Ctrl+C to stop.")
        serve_prototype(root, port)
    except (OSError, ValueError) as error:
        raise click.ClickException(str(error)) from error


if __name__ == "__main__":  # pragma: no cover
    phrase_gym()

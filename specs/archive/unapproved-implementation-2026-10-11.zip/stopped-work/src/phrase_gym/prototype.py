"""A localhost-only server for explicit prototype assets; no directory browsing."""

from contextlib import suppress
from functools import partial
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ASSETS = {
    "/": ("prototypes/drill-flow/index.html", "text/html; charset=utf-8"),
    "/app.js": ("prototypes/drill-flow/app.js", "text/javascript; charset=utf-8"),
    "/engine.mjs": ("prototypes/drill-flow/engine.mjs", "text/javascript; charset=utf-8"),
    "/styles.css": ("prototypes/drill-flow/styles.css", "text/css; charset=utf-8"),
    "/materials.json": ("fixtures/p1/materials.json", "application/json; charset=utf-8"),
}


def find_project(directory: Path | None = None) -> Path:
    """Find checkout assets from an explicit directory or the current working tree."""
    start = (directory or Path.cwd()).resolve()
    candidates = [start] if directory is not None else [start, *start.parents]
    for root in candidates:
        if all((root / relative).is_file() for relative, _ in ASSETS.values()):
            return root
    raise ValueError(
        "Prototype assets not found. Run from the Phrase Gym checkout or use --project-dir.",
    )


class PrototypeHandler(BaseHTTPRequestHandler):
    """Only serve the allowlisted P1 files, never the whole project or source archive."""

    def __init__(self, *args, project: Path, **kwargs):
        self.project = project
        super().__init__(*args, **kwargs)

    def do_GET(self) -> None:  # noqa: N802
        """Serve one local asset without allowing request paths to reach the filesystem."""
        self._serve(head=False)

    def do_HEAD(self) -> None:  # noqa: N802
        """Use the same allowlist for header-only requests."""
        self._serve(head=True)

    def _serve(self, *, head: bool) -> None:
        asset = ASSETS.get(urlsplit(self.path).path)
        if asset is None:
            self.send_error(404)
            return
        relative, content_type = asset
        try:
            content = (self.project / relative).read_bytes()
        except OSError:
            self.send_error(404, "Prototype asset unavailable")
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'")
        self.end_headers()
        if not head:
            self.wfile.write(content)


def serve_prototype(project: Path, port: int) -> None:
    """Run until Ctrl+C, closing the socket cleanly on exit."""
    handler = partial(PrototypeHandler, project=project)
    with (
        ThreadingHTTPServer(("127.0.0.1", port), handler) as server,
        suppress(KeyboardInterrupt),
    ):
        server.serve_forever()

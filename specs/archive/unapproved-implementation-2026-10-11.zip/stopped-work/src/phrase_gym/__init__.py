"""Phrase Gym: targeted word, phrase and prepared-dialogue drills."""

from phrase_gym.__about__ import __version__

__all__ = ["__version__"]

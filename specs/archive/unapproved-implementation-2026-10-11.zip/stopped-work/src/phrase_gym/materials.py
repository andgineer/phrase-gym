"""Structural guardrails for disposable P1 material, not the production content API."""

import json
from pathlib import Path
from typing import Any


class MaterialError(ValueError):
    """A prototype pack cannot safely be presented as a drill."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise MaterialError(message)


def _text(value: Any, location: str) -> None:
    _require(isinstance(value, str) and bool(value.strip()), f"{location}: non-empty text required")


def _objects(value: Any, location: str) -> list[dict[str, Any]]:
    _require(isinstance(value, list) and bool(value), f"{location}: non-empty list required")
    _require(all(isinstance(item, dict) for item in value), f"{location}: objects required")
    return value


def _ids(value: Any, location: str) -> list[str]:
    _require(isinstance(value, list) and bool(value), f"{location}: non-empty ID list required")
    for item in value:
        _text(item, location)
    _require(len(set(value)) == len(value), f"{location}: duplicate ID")
    return value


def _unique(items: list[dict[str, Any]], location: str) -> set[str]:
    return set(_ids([item.get("id") for item in items], location))


def _validate_cues(target: dict[str, Any], chunks: set[str]) -> None:
    key = target["id"]
    required = set(_ids(target.get("required_chunks"), f"{key}.required_chunks"))
    _require(required <= chunks, f"{key}: unknown required chunk")
    cues = _objects(target.get("cues"), f"{key}.cues")
    _unique(cues, f"{key}.cues")
    for cue in cues:
        label = f"{key}/{cue['id']}"
        visible = set(_ids(cue.get("visible_chunks"), label))
        _require(visible < chunks, f"{label}: show known anchors and hide at least one chunk")
        for field in ("task", "rationale"):
            _text(cue.get(field), f"{label}.{field}")
        _ids(cue.get("competitors"), f"{label}.competitors")
        _require(cue.get("review_status") == "author_checked", f"{label}: unchecked cue")
        expected = "partial_phrase"
        if target["kind"] != "fixed":
            expected = "usage" if required & visible else "target_recall"
        _require(cue.get("evidence") == expected, f"{label}: evidence must be {expected}")


def _validate_target(target: dict[str, Any]) -> None:
    key = target["id"]
    for field in ("language", "title", "purpose", "meaning", "full_text", "slots"):
        _text(target.get(field), f"{key}.{field}")
    _require(type(target.get("revision")) is int and target["revision"] > 0, f"{key}: revision")
    _require(target.get("kind") in ("fixed", "word", "frame"), f"{key}: unknown target kind")
    chunks = _objects(target.get("chunks"), f"{key}.chunks")
    chunk_ids = _unique(chunks, f"{key}.chunks")
    for chunk in chunks:
        _text(chunk.get("text"), f"{key}.{chunk['id']}")
    _require(
        " ".join(chunk["text"] for chunk in chunks) == target["full_text"],
        f"{key}: chunks do not reconstruct full_text",
    )
    variants = target.get("allowed_variants")
    if not isinstance(variants, list):
        raise MaterialError(f"{key}: allowed_variants must be a list")
    for variant in variants:
        _text(variant, f"{key}.allowed_variants")
    audio = target.get("audio")
    if not isinstance(audio, dict):
        raise MaterialError(f"{key}: audio provenance required")
    _require(audio.get("status") == "pending", f"{key}: this text prototype expects pending audio")
    _text(audio.get("source"), f"{key}.audio.source")
    _validate_cues(target, chunk_ids)


def _validate_dialogues(pack: dict[str, Any], targets: dict[str, dict[str, Any]]) -> None:
    dialogues = _objects(pack.get("dialogues"), "dialogues")
    _unique(dialogues, "dialogues")
    for dialogue in dialogues:
        key = dialogue["id"]
        for field in ("title", "purpose", "learner_role"):
            _text(dialogue.get(field), f"{key}.{field}")
        turns = _objects(dialogue.get("turns"), f"{key}.turns")
        _require(any("target_id" in turn for turn in turns), f"{key}: no target turns")
        for turn in turns:
            _text(turn.get("speaker"), f"{key}.speaker")
            if "target_id" not in turn:
                _text(turn.get("text"), f"{key}.supporting turn")
                _require("cue_id" not in turn, f"{key}: supporting turn cannot reference a cue")
                continue
            target_id = turn["target_id"]
            _require(isinstance(target_id, str) and target_id in targets, f"{key}: unknown target")
            _require("text" not in turn, f"{key}: target turn cannot also expose its answer")
            _require(turn["speaker"] == dialogue["learner_role"], f"{key}: target role mismatch")
            _require(
                turn.get("cue_id") in {cue["id"] for cue in targets[target_id]["cues"]},
                f"{key}: cue does not belong to target {target_id}",
            )


def validate_pack(pack: Any) -> dict[str, Any]:
    """Reject broken references, answer leaks labelled recall and unchecked candidates.

    This checks structure and evidence labels. It cannot certify natural language
    quality or detect every answer leaked through a task's prose.
    """
    _require(isinstance(pack, dict), "pack must be an object")
    _require(
        type(pack.get("schema_version")) is int and pack["schema_version"] == 1,
        "unsupported schema_version",
    )
    _require(type(pack.get("revision")) is int and pack["revision"] > 0, "pack revision required")
    _text(pack.get("id"), "pack.id")
    review = pack.get("review")
    _require(isinstance(review, dict), "pack.review required")
    _require(review.get("status") == "author_checked", "pack: review status required")
    for field in ("reviewer", "date", "limits"):
        _text(review.get(field), f"review.{field}")
    targets = _objects(pack.get("targets"), "targets")
    _unique(targets, "targets")
    for target in targets:
        _validate_target(target)
    _validate_dialogues(pack, {target["id"]: target for target in targets})
    rejected = _objects(pack.get("rejected_candidates"), "rejected_candidates")
    _unique(rejected, "rejected_candidates")
    for candidate in rejected:
        for field in ("reason", "prompt", "resolution"):
            _text(candidate.get(field), f"{candidate['id']}.{field}")
    return pack


def load_materials(path: Path) -> dict[str, Any]:
    """Read UTF-8 JSON and validate before any practice queue is created."""
    return validate_pack(json.loads(path.read_text(encoding="utf-8")))

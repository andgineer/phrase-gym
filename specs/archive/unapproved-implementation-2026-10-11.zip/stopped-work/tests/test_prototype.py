"""Exercise the actual local server, including its filesystem boundary."""

import threading
from functools import partial
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from pathlib import Path

import pytest
from click.testing import CliRunner

from phrase_gym.main import phrase_gym
from phrase_gym.prototype import ASSETS, PrototypeHandler, find_project, serve_prototype

ROOT = Path(__file__).resolve().parents[1]


def test_project_lookup_does_not_need_git(monkeypatch):
    monkeypatch.chdir(ROOT / "src/phrase_gym")
    assert find_project() == ROOT


def test_installed_cli_explains_missing_checkout(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    result = CliRunner().invoke(phrase_gym, ["prototype"])
    assert result.exit_code == 1
    assert "--project-dir" in result.output


def test_server_only_exposes_prototype_files():
    handler = partial(PrototypeHandler, project=ROOT)
    with ThreadingHTTPServer(("127.0.0.1", 0), handler) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        connection = HTTPConnection("127.0.0.1", server.server_port, timeout=5)
        try:
            for path, (_, mime) in ASSETS.items():
                connection.request("GET", path)
                response = connection.getresponse()
                assert response.status == 200
                assert response.getheader("Content-Type") == mime
                assert response.getheader("Cache-Control") == "no-store"
                assert response.read()
            connection.request("HEAD", "/materials.json")
            response = connection.getresponse()
            assert response.status == 200
            assert response.read() == b""
            for path in (
                "/README.md",
                "/../README.md",
                "/%2e%2e/README.md",
                "/spec/history/",
                "/.env",
            ):
                connection.request("GET", path)
                response = connection.getresponse()
                assert response.status == 404
                response.read()
        finally:
            connection.close()
            server.shutdown()
            thread.join(timeout=5)


def test_ctrl_c_closes_listener(monkeypatch):
    def interrupt(_server):
        raise KeyboardInterrupt

    monkeypatch.setattr(ThreadingHTTPServer, "serve_forever", interrupt)
    serve_prototype(ROOT, 0)


def test_explicit_project_must_contain_all_assets(tmp_path):
    with pytest.raises(ValueError, match="assets not found"):
        find_project(tmp_path)

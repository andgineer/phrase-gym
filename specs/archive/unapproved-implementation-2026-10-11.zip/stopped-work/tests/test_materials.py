"""Check learning-critical material invariants and malformed import handling."""

import copy
import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from phrase_gym.main import phrase_gym
from phrase_gym.materials import MaterialError, load_materials, validate_pack

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def pack():
    return load_materials(ROOT / "fixtures/p1/materials.json")


def test_pack_covers_target_kinds_and_dialogues(pack):
    assert {target["kind"] for target in pack["targets"]} == {"fixed", "word", "frame"}
    assert len(pack["targets"]) == 12
    assert len(pack["dialogues"]) == 2
    assert all(len(target["cues"]) >= 2 for target in pack["targets"])


def test_visible_word_cannot_be_labelled_recalled(pack):
    word = next(target for target in pack["targets"] if target["kind"] == "word")
    word["cues"][1]["evidence"] = "target_recall"
    with pytest.raises(MaterialError, match="evidence must be usage"):
        validate_pack(pack)


def test_cannot_show_whole_answer_as_a_recall_cue(pack):
    target = pack["targets"][0]
    target["cues"][0]["visible_chunks"] = [chunk["id"] for chunk in target["chunks"]]
    with pytest.raises(MaterialError, match="hide at least one"):
        validate_pack(pack)


def test_dialogue_must_use_cue_of_its_own_target(pack):
    pack["dialogues"][0]["turns"][1]["cue_id"] = "postpone-1"
    with pytest.raises(MaterialError, match="cue does not belong"):
        validate_pack(pack)


def test_dialogue_cannot_leak_target_in_supporting_text(pack):
    pack["dialogues"][0]["turns"][1]["text"] = "A revealed answer"
    with pytest.raises(MaterialError, match="cannot also expose"):
        validate_pack(pack)


@pytest.mark.parametrize(
    "field,value",
    [
        ("targets", []),
        ("targets", None),
        ("targets", ["wrong"]),
        ("schema_version", 99),
        ("schema_version", True),
        ("review", {}),
    ],
)
def test_malformed_pack_fails_with_actionable_error(pack, field, value):
    pack[field] = value
    with pytest.raises(MaterialError):
        validate_pack(pack)


def test_duplicate_id_or_unreviewed_cue_cannot_enter_queue(pack):
    duplicate = copy.deepcopy(pack)
    duplicate["targets"].append(duplicate["targets"][0])
    with pytest.raises(MaterialError, match="duplicate ID"):
        validate_pack(duplicate)
    pack["targets"][0]["cues"][0]["review_status"] = "draft"
    with pytest.raises(MaterialError, match="unchecked cue"):
        validate_pack(pack)


def test_chunk_text_must_reconstruct_full_model(pack):
    pack["targets"][0]["chunks"][0]["text"] = "Wrong model"
    with pytest.raises(MaterialError, match="reconstruct"):
        validate_pack(pack)


def test_language_metadata_and_unicode_are_not_english_only(pack):
    target = pack["targets"][0]
    target["language"] = "sr-Latn"
    target["chunks"] = [
        dict(chunk, text=text)
        for chunk, text in zip(target["chunks"], ["Kako je", "prošao", "tvoj dan?"], strict=True)
    ]
    target["full_text"] = "Kako je prošao tvoj dan?"
    assert validate_pack(pack)["targets"][0]["full_text"] == "Kako je prošao tvoj dan?"


def test_cli_validates_real_pack_and_reports_bad_json(tmp_path):
    runner = CliRunner()
    result = runner.invoke(
        phrase_gym, ["validate-materials", str(ROOT / "fixtures/p1/materials.json")]
    )
    assert result.exit_code == 0
    assert "12 targets, 24 cues, 2 dialogues" in result.output
    broken = tmp_path / "broken.json"
    broken.write_text('{"targets":')
    result = runner.invoke(phrase_gym, ["validate-materials", str(broken)])
    assert result.exit_code == 1
    assert "Expecting value" in result.output


def test_cli_reports_validation_error_without_traceback(tmp_path, pack):
    pack["targets"][0]["cues"][0]["visible_chunks"] = []
    source = tmp_path / "pack.json"
    source.write_text(json.dumps(pack))
    result = CliRunner().invoke(phrase_gym, ["validate-materials", str(source)])
    assert result.exit_code == 1
    assert "non-empty ID list" in result.output

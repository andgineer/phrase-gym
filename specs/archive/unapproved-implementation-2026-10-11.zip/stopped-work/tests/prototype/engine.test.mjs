import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { createSession, transition, current, evidence, restore, summarize } from "../../prototypes/drill-flow/engine.mjs";

const pack = JSON.parse(fs.readFileSync(new URL("../../fixtures/p1/materials.json", import.meta.url), "utf8"));
const step = (state, type, value) => transition(state, { type, value }, pack);
const answer = (state, value = "matched") => step(step(state, "said"), "outcome", value);

test("new expressions are introduced before recall; later masks keep one target", () => {
  let state = createSession(pack, { targetIds: ["day", "meet", "moment"] });
  assert.equal(state.stage, "introduce");
  assert.throws(() => step(state, "said"), /unavailable/);
  for (let index = 0; index < 3; index++) state = answer(step(state, "learned"));
  assert.equal(current(state).targetId, "day");
  assert.equal(current(state).cueId, "day-2");
  assert.equal(state.stage, "recall");
  assert.equal(evidence(state, pack), "partial_phrase");
  state = answer(state);
  assert.equal(summarize(state).length, 3);
  assert.equal(summarize(state)[0].attempts.length, 2);
  assert.equal(state.attempts[0].evidence, "model-assisted");
});

test("help exposure survives reload and is not upgraded by a success report", () => {
  let state = createSession(pack, { targetIds: ["day"], familiar: true });
  state = step(state, "help");
  const saved = restore(JSON.stringify(state), pack);
  assert.deepEqual(saved.support, ["model"]);
  state = answer(saved);
  assert.equal(state.attempts[0].evidence, "model-assisted");
});

test("deliberate model help is recorded and repair is requeued after other items", () => {
  let state = createSession(pack, { targetIds: ["day", "meet", "moment"], familiar: true });
  state = step(state, "model");
  assert.equal(state.stage, "repair");
  state = step(state, "repaired");
  assert.equal(state.attempts[0].outcome, "helped");
  assert.equal(state.attempts[0].evidence, "model-assisted");
  assert.equal(state.queue[3].targetId, "day");
  assert.equal(state.queue[3].retry, true);
  assert.equal(state.queue[3].cueId, "day-2");
});

test("difficulty survives successful repair; retries have a finite cap", () => {
  let state = createSession(pack, { targetIds: ["day"], familiar: true });
  let steps = 0;
  while (state.stage !== "summary") {
    state = answer(state, "difficult");
    state = step(state, "repaired");
    assert.ok(++steps < 10);
  }
  assert.equal(state.attempts.length, 4);
  assert.equal(state.retryCounts.day, 2);
  assert.ok(state.attempts.every(attempt => attempt.outcome === "difficult"));
});

test("alternatives and unclear cues are neither failures nor automatic retries", () => {
  let state = createSession(pack, { targetIds: ["day"], familiar: true });
  state = answer(state, "different");
  state = answer(state, "unclear");
  assert.equal(state.stage, "summary");
  assert.equal(state.queue.length, 2);
  assert.deepEqual(state.attempts.map(item => item.outcome), ["different", "unclear"]);
});

test("a shown word is usage practice, never lexical recall", () => {
  let state = createSession(pack, { targetIds: ["postpone"], familiar: true });
  state = answer(state);
  assert.equal(state.attempts[0].evidence, "target_recall");
  assert.equal(evidence(state, pack), "usage");
  state = answer(state);
  assert.equal(state.attempts[1].evidence, "usage");
});

test("dialogue is introduced, hard turn isolated then returned, supporting turns stay readable", () => {
  let state = createSession(pack, { dialogueId: "first-meeting" });
  assert.equal(state.stage, "dialogue-intro");
  state = step(state, "begin-dialogue");
  assert.equal(state.stage, "supporting");
  state = step(state, "next-line");
  state = answer(state, "difficult");
  assert.equal(state.stage, "repair");
  state = step(state, "repaired");
  assert.equal(current(state).targetId, "meet");
  assert.equal(current(state).turn, 1);
  assert.equal(current(state).retry, true);
  state = answer(state);
  assert.equal(state.stage, "supporting");
  assert.equal(summarize(state).length, 1);
  assert.equal(state.attempts[0].evidence, "after-dialogue-preview");
  assert.equal(state.attempts[1].evidence, "same-session-retry");
});

test("stale or broken saved content cannot silently resume", () => {
  const state = createSession(pack, { targetIds: ["day"] });
  assert.throws(() => restore(JSON.stringify({ ...state, packRevision: 99 }), pack), /different/);
  assert.throws(() => restore(JSON.stringify({ ...state, index: -1 }), pack), /incomplete/);
  assert.throws(() => restore(JSON.stringify({ ...state, queue: [{ targetId: "unknown" }] }), pack), /Unknown/);
  assert.throws(() => restore("null", pack), /different/);
});

test("reducer does not mutate the checkpoint it received", () => {
  const state = createSession(pack, { targetIds: ["day"] });
  const before = JSON.stringify(state);
  step(state, "learned");
  assert.equal(JSON.stringify(state), before);
});

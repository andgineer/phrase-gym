// Disposable P1 session reducer. No due dates, grading model or production progress.
export const VERSION = 1;
const outcomes = new Set(["matched", "difficult", "different", "unclear", "helped"]);

export function getTarget(pack, id) {
  const target = pack.targets.find(item => item.id === id);
  if (!target) throw new Error(`Unknown target: ${id}`);
  return target;
}

export function getCue(pack, item) {
  const cue = getTarget(pack, item.targetId).cues.find(entry => entry.id === item.cueId);
  if (!cue) throw new Error(`Unknown cue: ${item.cueId}`);
  return cue;
}

export function current(state) { return state.queue[state.index]; }

function prepare(state, pack) {
  state.visibleExtra = [];
  state.support = [];
  state.initialModel = false;
  state.repairReason = null;
  if (state.index >= state.queue.length) { state.stage = "summary"; return; }
  const item = current(state);
  if (item.text !== undefined) { state.stage = "supporting"; return; }
  getCue(pack, item);
  state.stage = state.introduced.includes(item.targetId) ? "recall" : "introduce";
  if (state.stage === "introduce") {
    state.initialModel = true;
    state.support.push("introduction");
  }
  // A dialogue preview disclosed each exact learner line before this first run.
  if (state.dialogueId && !item.retry) state.support.push("dialogue-preview");
}

export function createSession(pack, { targetIds, dialogueId, familiar = false }) {
  const state = {
    version: VERSION, packId: pack.id, packRevision: pack.revision,
    stage: "introduce", queue: [], index: 0, introduced: [], attempts: [],
    retryCounts: {}, support: [], visibleExtra: [], initialModel: false,
    dialogueId: dialogueId || null, familiar, repairReason: null,
  };
  if (dialogueId) {
    const dialogue = pack.dialogues.find(item => item.id === dialogueId);
    if (!dialogue) throw new Error("Unknown dialogue");
    state.queue = dialogue.turns.map((turn, index) => turn.target_id ? {
      targetId: turn.target_id, cueId: turn.cue_id, turn: index, retry: false,
    } : { speaker: turn.speaker, text: turn.text, turn: index });
    state.stage = "dialogue-intro";
  } else {
    if (!targetIds?.length || new Set(targetIds).size !== targetIds.length) {
      throw new Error("Choose distinct learned targets");
    }
    // Return after intervening targets and deliberately use another reviewed mask.
    state.queue = [0, 1].flatMap(round => targetIds.map(id => {
      const target = getTarget(pack, id);
      return { targetId: id, cueId: target.cues[round % target.cues.length].id, retry: false };
    }));
    if (familiar) state.introduced = [...targetIds];
    prepare(state, pack);
  }
  return state;
}

export function evidence(state, pack) {
  if (state.support.includes("model") || state.support.includes("introduction")) return "model-assisted";
  if (state.support.includes("chunk")) return "extra-help";
  if (state.support.includes("dialogue-preview")) return "after-dialogue-preview";
  if (current(state).retry) return "same-session-retry";
  return getCue(pack, current(state)).evidence;
}

function record(state, pack, outcome) {
  const item = current(state);
  state.attempts.push({
    targetId: item.targetId, cueId: item.cueId, outcome,
    evidence: evidence(state, pack), support: [...state.support],
    visibleExtra: [...state.visibleExtra], retry: Boolean(item.retry),
    dialogueId: state.dialogueId,
  });
  // Two retries at most per target, with no memory-failure inference for alternatives.
  if (["difficult", "helped"].includes(outcome) && (state.retryCounts[item.targetId] || 0) < 2) {
    state.retryCounts[item.targetId] = (state.retryCounts[item.targetId] || 0) + 1;
    const cues = getTarget(pack, item.targetId).cues;
    const next = cues[(cues.findIndex(cue => cue.id === item.cueId) + 1) % cues.length];
    const retry = { ...item, cueId: next.id, retry: true };
    // Dialogue repair is repeated at the original position after its isolated repair.
    // Other sessions wait for two intervening targets where available.
    const at = state.dialogueId ? state.index + 1 : Math.min(state.index + 3, state.queue.length);
    state.queue.splice(at, 0, retry);
  }
  state.index += 1;
  prepare(state, pack);
}

export function transition(previous, action, pack) {
  const state = structuredClone(previous);
  const item = current(state);
  if (action.type === "begin-dialogue" && state.stage === "dialogue-intro") {
    state.introduced = [...new Set(state.queue.filter(row => row.targetId).map(row => row.targetId))];
    prepare(state, pack);
  } else if (action.type === "next-line" && state.stage === "supporting") {
    state.index += 1;
    prepare(state, pack);
  } else if (action.type === "learned" && state.stage === "introduce") {
    if (!state.introduced.includes(item.targetId)) state.introduced.push(item.targetId);
    state.stage = "recall";
  } else if (action.type === "teach" && state.stage === "recall") {
    state.support.push("introduction");
    state.stage = "introduce";
  } else if (action.type === "help" && state.stage === "recall") {
    const target = getTarget(pack, item.targetId);
    const visible = [...getCue(pack, item).visible_chunks, ...state.visibleExtra];
    const hidden = target.chunks.filter(chunk => !visible.includes(chunk.id));
    if (!hidden.length) throw new Error("All chunks are already visible");
    state.visibleExtra.push(hidden[0].id);
    state.support.push(hidden.length === 1 ? "model" : "chunk");
  } else if (action.type === "model" && state.stage === "recall") {
    state.support.push("model");
    state.repairReason = "helped";
    state.stage = "repair";
  } else if (action.type === "said" && state.stage === "recall") {
    state.stage = "compare";
  } else if (action.type === "outcome" && state.stage === "compare" && outcomes.has(action.value)) {
    if (action.value === "difficult") {
      state.repairReason = "difficult";
      state.stage = "repair";
    } else {
      record(state, pack, action.value);
    }
  } else if (action.type === "repaired" && state.stage === "repair") {
    // Repair never upgrades the difficult first response to success.
    record(state, pack, state.repairReason);
  } else {
    throw new Error(`Action ${action.type} is unavailable in ${state.stage}`);
  }
  return state;
}

export function summarize(state) {
  const rows = new Map();
  for (const attempt of state.attempts) {
    const row = rows.get(attempt.targetId) || { targetId: attempt.targetId, attempts: [] };
    row.attempts.push(attempt);
    rows.set(attempt.targetId, row);
  }
  return [...rows.values()];
}

export function restore(serialized, pack) {
  const state = JSON.parse(serialized);
  if (state?.version !== VERSION || state.packId !== pack.id || state.packRevision !== pack.revision) {
    throw new Error("This saved walkthrough uses a different content version.");
  }
  if (!Array.isArray(state.queue) || !state.queue.length || !Number.isInteger(state.index) ||
      state.index < 0 || state.index > state.queue.length || !Array.isArray(state.support) ||
      !Array.isArray(state.visibleExtra) || !Array.isArray(state.attempts) ||
      !Array.isArray(state.introduced) || !state.retryCounts ||
      !["introduce", "recall", "compare", "repair", "summary", "supporting", "dialogue-intro"].includes(state.stage)) {
    throw new Error("The saved walkthrough is incomplete. Start a new one.");
  }
  for (const item of state.queue) {
    if (item.targetId) getCue(pack, item);
    else if (typeof item.text !== "string" || typeof item.speaker !== "string") throw new Error("Invalid supporting turn");
  }
  for (const attempt of state.attempts) {
    getCue(pack, attempt);
    if (!outcomes.has(attempt.outcome) || !Array.isArray(attempt.support)) throw new Error("Invalid attempt");
  }
  if (state.stage === "summary" ? state.index !== state.queue.length : state.index >= state.queue.length) {
    throw new Error("Invalid saved position");
  }
  return state;
}

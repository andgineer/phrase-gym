import { createSession, transition, current, getTarget, getCue, summarize, restore, evidence } from "/engine.mjs";

const app = document.querySelector("#app");
const KEY = "phrase-gym:p1:v1";
const label = {
  "partial_phrase": "Partial phrase cue", "target_recall": "Sentence cue · target hidden",
  "usage": "Target shown · usage practice", "model-assisted": "Practised after seeing the model",
  "extra-help": "Practised with extra help", "after-dialogue-preview": "Practised after reading the dialogue",
  "same-session-retry": "Same-session retry", "matched": "Matched the target",
  "difficult": "Needed repair", "different": "Different wording · no failure recorded",
  "unclear": "Unclear cue · no failure recorded", "helped": "Model help used",
};
let pack, state = null, saved = null, storageIssue = "", started = false, paused = false;

// Content is always inserted as text, including fixture and restored data.
function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}
function button(text, handler, kind = "primary") {
  const node = el("button", text, kind);
  node.type = "button";
  node.addEventListener("click", handler);
  return node;
}
function section(title, body) {
  const node = el("section", undefined, "card");
  node.append(el("h2", title));
  if (body) node.append(el("p", body, "muted"));
  return node;
}
function notice() {
  if (storageIssue) app.append(el("p", storageIssue, "warning"));
}
function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); storageIssue = ""; saved = state; }
  catch { storageIssue = "Your browser could not save this walkthrough. You can continue, but reloading may lose this step."; }
}
function act(type, value) {
  try { state = transition(state, { type, value }, pack); persist(); render(); }
  catch (error) { app.append(el("p", error.message, "warning")); }
}
function launch(options) {
  state = createSession(pack, options); started = true; paused = false; persist(); render();
}
function heading(kicker, title, body) {
  app.append(el("p", kicker, "eyebrow"), el("h1", title));
  if (body) app.append(el("p", body, "lede"));
}
function home() {
  app.replaceChildren();
  heading("Small sessions. Useful language.", "Make the words come easier.",
    "Learn an expression, recall it from a useful cue, and say the whole phrase aloud. Try a short set to see each step.");
  notice();
  if (saved && saved.stage !== "summary") {
    const resume = section("Your paused walkthrough", "Resume the same step with any model or extra help still recorded.");
    resume.append(button("Resume walkthrough", () => { state = saved; started = true; paused = false; render(); }));
    app.append(resume);
  }
  const preference = el("label", undefined, "check");
  const checkbox = document.createElement("input"); checkbox.type = "checkbox";
  preference.append(checkbox, document.createTextNode("I've learned these expressions before — start with recall"));
  app.append(preference);
  const sets = el("div", undefined, "grid");
  [
    ["First phrases", "Meet a colleague, ask about their day, and take a moment to think.", ["day", "meet", "moment"]],
    ["Words in phrases", "Retrieve three selected words, then practise using them with different parts hidden.", ["postpone", "available", "compromise"]],
    ["Reusable patterns", "Make a polite request, anticipate working together, and describe a familiar routine.", ["mind", "forward", "used"]],
    ["Clarify and respond", "Check a meaning, acknowledge an argument, and restate a longer message.", ["mean", "point", "understand"]],
  ].forEach(([title, body, targetIds]) => {
    const card = section(title, body);
    card.append(el("p", "3 targets · 2 cue versions each", "meta"),
      button(`Try ${title.toLowerCase()}`, () => launch({ targetIds, familiar: checkbox.checked }), "secondary"));
    sets.append(card);
  });
  app.append(sets, el("h2", "Rehearse a specific dialogue"));
  const dialogues = el("div", undefined, "grid");
  pack.dialogues.forEach(dialogue => {
    const card = section(dialogue.title, dialogue.purpose);
    card.append(button("Read and rehearse", () => launch({ dialogueId: dialogue.id }), "secondary"));
    dialogues.append(card);
  });
  app.append(dialogues);
  if (saved) app.append(button("Clear this browser's walkthrough", () => {
    try { localStorage.removeItem(KEY); saved = null; state = null; storageIssue = ""; home(); }
    catch { storageIssue = "The browser did not allow the saved walkthrough to be removed."; home(); }
  }, "quiet"));
}
function dialoguePreview() {
  const dialogue = pack.dialogues.find(item => item.id === state.dialogueId);
  heading("Learn the exchange first", dialogue.title, "Read both sides. Say the lines labelled You aloud; then rehearse your side with cues.");
  const card = section("The complete dialogue", dialogue.purpose);
  dialogue.turns.forEach(turn => {
    const line = el("p", undefined, turn.speaker === "You" ? "dialogue you" : "dialogue");
    line.append(el("strong", `${turn.speaker}: `), document.createTextNode(turn.text || getTarget(pack, turn.target_id).full_text));
    card.append(line);
  });
  card.append(button("I've read it — rehearse my side", () => act("begin-dialogue")));
  app.append(card);
}
function phrase(target, visible = null) {
  const line = el("p", undefined, "phrase");
  target.chunks.forEach((chunk, index) => {
    if (index) line.append(document.createTextNode(" "));
    const hidden = visible && !visible.includes(chunk.id);
    const part = el("span", hidden ? "[…]" : chunk.text, hidden ? "gap" : "chunk");
    if (hidden) part.setAttribute("aria-label", "missing phrase chunk");
    line.append(part);
  });
  return line;
}
function context(card) {
  if (!state.dialogueId) return;
  const item = current(state);
  const dialogue = pack.dialogues.find(entry => entry.id === state.dialogueId);
  const preceding = dialogue.turns.slice(0, item.turn).filter(turn => !turn.target_id).at(-1);
  if (preceding) card.append(el("p", `${preceding.speaker}: “${preceding.text}”`, "partner"));
  if (item.retry) card.append(el("p", "Back in the exchange · try this turn again with its partner line.", "meta"));
}
function renderAttempt() {
  const item = current(state), target = getTarget(pack, item.targetId), cue = getCue(pack, item);
  const titles = { introduce: "Meet this expression.", recall: "Your turn. Say the whole phrase.", compare: "How did your phrase compare?", repair: "Give this phrase another try." };
  heading(state.dialogueId ? "Your side of the dialogue" : "One expression at a time", titles[state.stage], target.purpose);
  const card = section(state.stage === "recall" ? "Recall the expression you learned" : "The expression");
  context(card);
  if (state.stage === "recall") {
    card.append(el("p", cue.task), phrase(target, [...cue.visible_chunks, ...state.visibleExtra]));
    card.append(el("p", "Say the complete sentence aloud, including the visible words. Nothing is being recorded.", "instruction"));
    card.append(button("I've said it — compare", () => act("said")));
    const controls = el("div", undefined, "actions");
    if (new Set([...cue.visible_chunks, ...state.visibleExtra]).size < target.chunks.length) {
      controls.append(button("Show one more chunk", () => act("help"), "secondary"));
    }
    controls.append(button("Show the model and practise", () => act("model"), "secondary"),
      button("I haven't learned this yet", () => act("teach"), "quiet"));
    card.append(controls);
    if (state.support.length) card.append(el("p", `Support recorded: ${label[evidence(state, pack)]}.`, "meta"));
    if (cue.evidence === "usage") card.append(el("p", "The target is shown here. This turn practises its use, rather than recall of the target itself.", "meta"));
  } else {
    card.append(phrase(target));
    if (state.stage === "introduce") {
      card.append(el("p", target.meaning), el("p", target.slots, "muted"),
        el("p", "Read the complete phrase aloud once. When its meaning is clear, hide it and try the cue.", "instruction"),
        button("Hide the model and try", () => act("learned")));
    } else if (state.stage === "compare") {
      if (target.allowed_variants.length) card.append(el("p", `Also allowed: ${target.allowed_variants.join(" / ")}`, "muted"));
      card.append(el("p", target.slots, "muted"), el("p", "Compare with what you said before revealing this model. This is your own check; the app has not assessed your speech.", "instruction"));
      const controls = el("div", undefined, "outcomes");
      [["Matched the target", "matched"], ["I struggled — practise it", "difficult"], ["I used different wording", "different"], ["The cue was unclear", "unclear"]].forEach(([text, value], index) => {
        controls.append(button(text, () => act("outcome", value), index === 0 ? "primary" : "secondary"));
      });
      card.append(controls, el("p", "Different wording can be good English. An unclear cue needs revision. Neither is recorded as a memory failure.", "meta"));
    } else {
      card.append(el("p", state.dialogueId ? "Practise just this line aloud with the model. Then return to the exchange and try it with the partner's line." : "Say the complete phrase aloud with the model. It will return after other items where possible, with help recorded.", "instruction"),
        button(state.dialogueId ? "I've practised — return to the exchange" : "I've practised — continue", () => act("repaired")));
    }
  }
  app.append(card);
}
function results() {
  heading("Walkthrough complete", "A little closer to ready.", "One result per target, with every attempt and the support you used. This prototype does not create review dates or measure fluency.");
  for (const row of summarize(state)) {
    const card = section(getTarget(pack, row.targetId).full_text);
    const list = el("ul");
    row.attempts.forEach(attempt => list.append(el("li", `${label[attempt.outcome]} · ${label[attempt.evidence]}`)));
    card.append(list); app.append(card);
  }
  app.append(button("Choose another walkthrough", () => { started = false; home(); }));
}
function render() {
  app.replaceChildren();
  notice();
  if (paused) {
    heading("Paused", "Pick up where you left off.", "Your step and the help already used are saved in this browser when storage is available.");
    app.append(button("Continue this walkthrough", () => { paused = false; render(); }),
      button("Choose another walkthrough", () => { started = false; home(); }, "secondary"));
  } else if (state.stage === "dialogue-intro") dialoguePreview();
  else if (state.stage === "summary") results();
  else if (state.stage === "supporting") {
    const item = current(state);
    heading("The dialogue continues", item.speaker === "You" ? "Your supporting line." : `${item.speaker}'s turn.`, "Supporting lines stay readable. They are not separate learning targets.");
    const card = section(item.speaker === "You" ? "Say this line aloud" : "Read your partner's line");
    card.append(el("p", item.text, "phrase"), button("Continue dialogue", () => act("next-line"))); app.append(card);
  } else renderAttempt();
  if (!paused && state.stage !== "summary") app.append(button("Pause walkthrough", () => { paused = true; persist(); render(); }, "quiet"));
  const h1 = app.querySelector("h1");
  if (h1) { h1.tabIndex = -1; h1.focus({ preventScroll: true }); }
  window.scrollTo(0, 0);
}

try {
  const response = await fetch("/materials.json");
  if (!response.ok) throw new Error("Could not load the practice material.");
  pack = await response.json();
  try {
    const stored = localStorage.getItem(KEY);
    if (stored) saved = restore(stored, pack);
  } catch (error) { storageIssue = `Saved walkthrough unavailable: ${error.message} Start a new walkthrough below.`; }
  home();
} catch (error) {
  app.replaceChildren(el("h1", "The walkthrough couldn't start."), el("p", error.message));
  app.append(button("Try loading again", () => location.reload()));
}
window.addEventListener("pagehide", () => { if (started && state) persist(); });

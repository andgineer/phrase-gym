# P1 cue review sheet

Author check: Codex, 2026-10-11. Learner review and audio checks are pending. These are prototype examples, not published teaching material.

Every cue requests a previously introduced expression and a complete spoken sentence. Competitors below explain the remaining uncertainty. Different wording and Unclear cue are always available; neither automatically means a memory failure.

The targets and cues live in [the versioned fixture pack](../../fixtures/p1/materials.json). Audio is explicitly pending for every realization; the first flow prototype is text-only. No browser TTS is substituted.

## day — How has your day been so far?

Ask about your colleague's day up to now.

Allowed use: No substitutions in this fixed expression.

- **day-1**: […] your day been so far? — `partial_phrase`. The present-perfect ending and day identify the learned question; the whole opening is retrieved.
  - How is your day going? changes the visible ending.
  - How was your day? changes both tense and the visible ending.
- **day-2**: How has […] been so far? — `partial_phrase`. The time span and explicit listener's day distinguish the missing subject from week or meeting.
  - How has your week been so far? does not match the requested day.

## meet — It's great to finally meet you in person.

Greet a colleague you have previously met only online.

Allowed use: No substitutions in this fixed expression.

- **meet-1**: It's great […] in person. — `partial_phrase`. The evaluation and in-person anchor constrain the learned greeting; finally belongs to the recalled chunk.
  - It's great to see you in person is natural: use Different wording if that is what came to mind.
- **meet-2**: […] to finally meet you in person. — `partial_phrase`. The full first-meeting complement identifies this target within the pack; the evaluation is recalled.
  - It's lovely to finally meet you in person is valid English, but different learned wording.

## point — That's a good point.

A colleague suggests allowing more time for testing. Acknowledge the merit of that point.

Allowed use: No substitutions in this fixed expression.

- **point-1**: […] a good point. — `partial_phrase`. The noun phrase anchors the learned acknowledgement rather than an unrelated agreement formula.
  - That's a fair point changes the visible adjective.
  - You've made a good point is natural alternative wording.
- **point-2**: That's a good […] — `partial_phrase`. Retaining a good avoids guessing between good and fair; the useful-argument meaning identifies point rather than idea.
  - That's a good idea evaluates a proposed action rather than the argument specified here.

## moment — Could you give me a moment to think about it?

Someone asks for your decision. Politely ask for a short thinking pause.

Allowed use: No substitutions in this fixed expression.

- **moment-1**: […] give me a moment to think about it? — `partial_phrase`. The body fixes the request; could in the instruction disambiguates the modal. This is supported practice.
  - Can you give me a moment to think about it? is natural, but the task explicitly supplies could.
- **moment-2**: Could you give me a moment […] — `partial_phrase`. The intact request anchors the target and the purpose identifies the thinking complement.
  - Could you give me a moment to check? changes the stated purpose.

## mean — What exactly do you mean by that?

Your colleague says the proposal needs to be more flexible. Ask them to clarify that statement.

Allowed use: No substitutions in this fixed expression.

- **mean-1**: What exactly […] by that? — `partial_phrase`. Exactly and by that identify the clarification pattern in the learned set.
  - What exactly are you suggesting by that? is possible but is a different question.
- **mean-2**: […] do you mean by that? — `partial_phrase`. The retained question body plus precision purpose prompts What exactly rather than How.
  - What do you mean by that? omits the learned precision word.

## understand — If I understand you correctly, you're saying that we need more time.

Confirm that your colleague means the team needs more time.

Allowed use: No substitutions in this fixed expression.

- **understand-1**: If I understand you correctly, […] we need more time. — `partial_phrase`. Both the tentative opening and concrete message remain; the linking chunk is retrieved.
  - If I understand you correctly, we need more time is shorter valid wording; it omits the target link.
- **understand-2**: […] you're saying that we need more time. — `partial_phrase`. The intact restatement plus the if hint identify the long opening in this pack.
  - As I understand it, you're saying that we need more time is natural but uses a different opening.

## postpone — We need to postpone the meeting.

The team cannot meet today. Say that the meeting needs to move to a later time.

Allowed use: Use postpone in the selected sense. The meeting / our meeting are allowed here; a later controlled example may change the event.

- **postpone-1**: We need to […] the meeting. — `target_recall`. The learned sense and complete sentence frame specify the task; delay is still a valid alternative to report.
  - We need to delay the meeting is valid English. Different wording records it without a memory failure.
- **postpone-2**: […] postpone the meeting. — `usage`. The word is visible: this practises its use and cannot establish retrieval of postpone.
  - We should postpone the meeting is appropriate but changes the selected need-to frame.

## available — Are you available for a quick call?

Ask whether your colleague has time for a brief call.

Allowed use: Keep the adjective available in the free-to-do-something sense; quick/short call are both allowed.

- **available-1**: Are you […] for a quick call? — `target_recall`. The selected learned adjective is the target; free is natural competing wording and is handled explicitly.
  - Are you free for a quick call? is natural English but does not retrieve available.
- **available-2**: Are you available […] — `usage`. Available stays visible; the learner completes its complement, practising use only.
  - Are you available for a short call? is an allowed realization.

## compromise — Let's find a compromise that works for both sides.

Both sides must give up something to reach agreement. Suggest the next step.

Allowed use: Keep compromise as an agreement noun; that works for / that suits both sides are allowed.

- **compromise-1**: Let's find […] that works for both sides. — `target_recall`. The concessions meaning distinguishes compromise from any agreement, without showing the noun.
  - Let's find a solution that works for both sides is broader and does not specify concessions.
- **compromise-2**: Let's find a compromise […] — `usage`. The noun is visible; only the surrounding use is practised.
  - Let's find a compromise that suits both sides is allowed.

## mind — Would you mind sending me the updated figures?

Politely ask your colleague to send you the updated figures.

Allowed use: Frame: Would you mind + verb-ing. This scene asks for sending me the updated figures; other actions belong to later controlled scenes.

- **mind-1**: Would you mind […] the updated figures? — `usage`. The construction opening is visible; producing the -ing action practises use, not recall of the whole construction.
  - Would you mind to send me ... does not fit this construction.
- **mind-2**: […] sending me the updated figures? — `usage`. The -ing chunk and bother meaning anchor Would you mind; part of the construction remains shown.
  - Could you sending me ... is ungrammatical; Would you consider sending me ... changes the request nuance.

## forward — I'm looking forward to working with you.

Tell your new colleague that you anticipate working together with pleasure.

Allowed use: Keep look forward to + -ing; I'm/I am are equivalent. Other activities need their own scene.

- **forward-1**: I'm […] working with you. — `target_recall`. The -ing complement and learned meaning cue the selected construction without displaying it.
  - I'm excited about working with you is natural alternative wording, not evidence of forgetting.
- **forward-2**: I'm looking forward to […] — `usage`. The target construction is shown; the -ing complement is practised.
  - I'm looking forward to work with you uses an infinitive where this frame needs -ing.

## used — I'm used to working remotely.

Explain that working remotely is already familiar and normal for you.

Allowed use: Keep be used to + -ing. I'm/I am are equivalent; the current action is working remotely.

- **used-1**: I'm […] working remotely. — `target_recall`. The semantic distinction and -ing complement select be used to in the learned set.
  - I'm comfortable working remotely is natural but different wording.
  - I used to work remotely describes a past habit instead.
- **used-2**: I'm used to […] — `usage`. The target is displayed; forming the -ing complement is usage practice only.
  - I'm used to work remotely confuses the accustomed-to frame with the past-habit pattern.

## Review checklist

The pack includes a long expression (understand), contractions (meet/point), -ing frames (mind/forward/used), three lexical senses, visible-word usage cues, and rejection fixtures for broad prompts, guessing and arbitrary masks. No claim of uniqueness across English is made. Some masks still invite natural alternatives; the walkthrough must establish whether the initial identifying material is sufficient for this learner.

# Phrase Gym — interaction design to produce

Updated 2026-10-11. **The first text-only prototype exists for review; its interaction design is not yet approved.** See [P1 implementation evidence](../plan/evidence/p1-first-slice.md) and run `uv run phrase-gym prototype` from the new checkout. Earlier conversation sketches are exploratory material only. The [targeted-drilling decision](../decision-targeted-drilling.md) is the baseline; follow [P1 prototyping](../plan/01-prototyping.md) to create and validate the design.

The prototype must make each step concrete: what the learner sees/hears, the whole phrase they should say, what help reveals, how comparison works and what happens after success, difficulty, different wording or an unclear cue.

Produce and review:

- new-expression introduction, phrase recall and word/frame practice;
- sufficient phrase-specific cues and useful changes to the hidden chunks;
- full-phrase responses, model comparison, repair and delayed return;
- specific dialogue rehearsal with supporting lines and a difficult-turn detour;
- pause/resume and recording/permission/interruption states;
- a clear result that distinguishes support from independent recall;
- navigation to practice, content and dialogues, with no requirement to inherit earlier labels or layouts.

Compare a focused phrase view and a context-visible view if useful. Mobile-first PWA, optional recording and the broader navigation are architecture/design recommendations pending the prototype; no previous selected carousel state constitutes user approval.

The runnable first slice covers text interactions and local checkpoints. Recorded user feedback, audio/device findings and revised design decisions are still required. The [roadmap](../plan/implementation-plan.md) keeps that work ahead of production implementation.

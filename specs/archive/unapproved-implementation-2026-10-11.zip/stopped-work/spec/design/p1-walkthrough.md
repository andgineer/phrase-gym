# First prototype walkthrough

Run `uv run phrase-gym prototype` from the project root and open `http://127.0.0.1:8765`. These are review scenarios, not completed usability findings. Audio is explicitly absent in this first slice; read the model and say your response aloud.

1. **New phrase:** choose First phrases with the familiar-expression checkbox off. Read “How has your day been so far?”, its meaning and purpose. Say it, press Hide the model and try, then say the complete question from the partial cue. Press I've said it — compare and report your result. The first result remains model-assisted.
2. **Known phrase / changed cue:** on the home screen, mark that you have already learned the set. Start First phrases and respond to each cue. After two other targets, the day question returns with another meaningful part hidden. If an expression is unfamiliar, choose I haven't learned this yet.
3. **Help / repair:** choose Show one more chunk or Show the model and practise. Say the complete phrase; continue. A model-assisted response remains labelled as such. A difficult target returns after intervening items where available, with at most two added retries.
4. **Word / construction:** choose Words in phrases or Reusable patterns. Compare the first cue with the next version. When the target itself is shown, the result is usage practice, never lexical recall. Allowed contractions, complements and substitutions appear with the model.
5. **Alternative / unclear cue:** after saying your response, compare and choose I used different wording or The cue was unclear. Continue. Results preserve the report and do not infer forgetting or automatically retry a defective cue.
6. **Specific dialogue:** choose Read and rehearse. Read both sides and say your side before starting. Partner and supporting lines stay readable. On a target turn choose I struggled, practise that line in isolation, and return to the same exchange with the partner line. The preview and same-session retry remain distinct from delayed recall.
7. **Pause / reload:** ask for help, pause, then reload. Resume from the start screen. The same step and help remain recorded. Storage errors produce a warning; the app does not claim the step was saved when the browser rejects it.

At the end, check that results group all cue versions and dialogue attempts under the same learning target. There are no due dates, scores or claims of independent fluency.

Review questions: Was the requested expression identifiable from its initial cue? Did you know what complete response to say and when to compare? Did the model/support labels describe what happened? Which cue should be strengthened or allowed to accept more wording? Record the user's actual answers in P1 evidence; do not infer approval from this guide.

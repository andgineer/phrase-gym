# Phrase Gym — implementation roadmap

Updated 2026-10-11. **P1 is in progress in `~/projects/phrase-gym`: an author-checked fixture pack and a runnable text-only interaction prototype are available for review. P2–P6 are not started.** Earlier sketches and legacy files do not satisfy any milestone. See the [P1 implementation evidence](evidence/p1-first-slice.md).

The sole agreed learning-behaviour baseline is [targeted drilling](../decision-targeted-drilling.md). The app name is Phrase Gym. The [architecture](../architecture.md) and proposed defaults are recommendations to validate, not additional user-approved requirements.

## Delivery sequence

| Phase | User-visible result | Detailed work | Depends on |
|---|---|---|---|
| **P1 — Prototype and validate** | Try the actual cue, response, help and repair flow; compare the model with a real recording on the phone. | [Prototyping](01-prototyping.md) | Agreed drilling decision only |
| **P2 — Foundation and content** | Open a real local app, import a reviewed collection and hear its model audio. | [Core implementation](02-core-implementation.md) | P1 findings and selected scope |
| **P3 — Complete core trainer** | Practise phrases and words in phrases, rehearse dialogues, pause/resume and return for due reviews with durable history. | [Core implementation](02-core-implementation.md) | P2 |
| **P4 — Phone reliability** | Save/compare voice takes and complete a prepared session through a connection loss without losing or duplicating reviews. | [Validation and release](04-validation-and-release.md) | P3; P1 audio probe |
| **P5 — Content preparation and intake** | Prepare reviewed material with AI and send selected words/phrases from echo-words into the same trainer. | [Content and integrations](03-content-and-integrations.md) | P2 contracts; P3 working drills |
| **P6 — Private pilot and release** | Use the app on a chosen private HTTPS host, with measured behaviour, backups and a tested recovery path. | [Validation and release](04-validation-and-release.md) | P3–P5; actual device evidence |

P4 and P5 can be developed independently after the core is stable. Choose the host in P6; a temporary development HTTPS endpoint needed for P1 is not a hosting decision.

## Recommended first release

Include fixed expressions and selected words/frames from the beginning, with reviewed partial cues, meaningful mask changes, introduction/model help, spoken self-check, repair, bounded dialogues and one target schedule. The first useful local slice is P3; P4 adds device resilience and saved recordings. Recommend completing P5 before calling the source-replacement workflow finished.

Use a reviewed manual content package while building the core. This stages integration work without redefining the product as phrases-only. Support explicit language metadata throughout; use the learner's English material first, plus fixtures that catch assumptions about Serbian/German text. The actual launch language set remains a prototype/pilot choice.

Defer automatic speech grading, locked-screen/eyes-free operation, arbitrary offline session creation, old Anki history migration, social features and additional host infrastructure. These are not prerequisites for proving the agreed learning loop. Open-ended AI conversation remains excluded entirely.

## Working rules for implementation

- Each work package ends with its listed artifact and observable checks. Update status using evidence, not the presence of a mockup or an unchecked task list.
- Keep production and prototype code separate. Reuse a prototype component only after inspecting its contracts, behaviour, error paths and tests.
- Treat content, cue and scheduling changes as versioned changes. Preserve attempts and their actual support history.
- Test pure session/scheduling rules with controlled clocks and fixtures; test persistence through transaction/retry cases; use browser/device tests for actual user flows. Avoid tests that merely repeat rendered labels or mock every relevant behaviour.
- AI output needs real model evaluation on reviewed fixtures. Mocked provider calls test plumbing only. A model's self-check cannot certify cue quality.
- Future changes to echo-words follow its own repository instructions and checks at that time. This planning task changes no echo-words code or Anki data.
- No prototype, stack, host, migration or release is recorded as accepted merely because it appears in this plan. Ask for the user's judgment when there is a concrete prototype or deployment proposal to inspect.

## Milestone evidence to retain

Each phase records a short report in `spec/plan/evidence/` when it is actually performed: build/version, device/browser where relevant, tested scenarios, outcomes, remaining limitations, decisions and links to the runnable result. The [first P1 report](evidence/p1-first-slice.md) records the initial implementation and its remaining checks. Keep personal recordings out of source control and these reports; use identifiers and consented examples.

## Current implementation and next work

The user created a Python package scaffold in `~/projects/phrase-gym` and authorized implementation on 2026-10-11. Preserve its `src/phrase_gym`, hatchling/uv packaging, Click entry point, pytest, Invoke and documentation/build workflows. The template file-conversion CLI is replaced with material validation and a localhost prototype launcher. `spec/` is the home of all development documentation; `docs/` remains the scaffold’s user-documentation site.

Run `uv run phrase-gym prototype` from this checkout. The disposable browser client uses plain JavaScript and localStorage; these are P1 tools, not a change to the proposed production stack. Next: review the cue examples and seven walkthroughs, refine any confusing cues, then build P1.3’s real-device audio/storage probe. P1.4 still precedes production foundation work.

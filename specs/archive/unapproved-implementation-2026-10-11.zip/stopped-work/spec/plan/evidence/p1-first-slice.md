# P1 first implementation — 2026-10-11

Status: P1 is in progress. P1.1 and P1.2 have a first implementation for learner review. P1.3 audio/device work and P1.4 production decisions are not started. P2–P6 remain not started. There is no production progress or scheduling implementation.

## Delivered

- The user's Python scaffold is retained: src layout, hatchling/uv packaging, rich-click entry point, pytest, Invoke, CI and documentation site.
- The file-conversion CLI template is replaced with `phrase-gym validate-materials [PACK]` and `phrase-gym prototype [--port PORT] [--project-dir CHECKOUT]`.
- [Fixture pack](../../../fixtures/p1/materials.json): 12 English targets (six fixed expressions, three word senses, three frames), 24 cue variants, two prepared dialogues and five rejected candidates. [Cue review sheet](../../design/p1-cue-review.md).
- [Disposable browser prototype](../../../prototypes/drill-flow/index.html): four short sets, full introductions, planned cue rotation, whole-phrase self-check, model/chunk help, repair and capped return, explicit different-wording/unclear-cue outcomes, dialogue preview and hard-turn return, pause/reload, and one result per target.
- localStorage contains only temporary text walkthrough state. Help is checkpointed before rerendering. Storage failure is reported. This is not the proposed production IndexedDB journal or a complete persistence guarantee.
- The local server allowlists five assets and binds only to localhost. The private historical archive, project files and directory listings are not served.

## Verification

- Python 3.13.13: 23 pytest tests passed; measured source coverage was 95%. Tests cover material/reference integrity, hidden versus shown targets, CLI errors and real HTTP allowlist behaviour.
- Node 20.15.1: nine reducer tests passed, covering introduction, mask rotation, help/reload, repair retention and retry cap, alternatives/ambiguity, shown-word usage, dialogue return, saved-version rejection and immutable transitions.
- Ruff 0.9.3 with the scaffold's rule selection passed. Pyrefly 0.50.0 reported no errors. YAML and text hygiene were checked directly with the scaffold's hook tools. The `inv pre` wrapper cannot run because this folder has no Git metadata; Git was not initialized to work around that limitation.
- Both documentation variants built successfully with the existing Invoke/Zensical workflow after the dependency correction documented in the [migration record](project-move.md).
- Browser: Codex in-app browser on macOS. Walked through new phrase, model help, pause/reload, alternatives, unclear cue, rotating masks, final grouped results, and the first dialogue's hard-turn repair/return. At a 320 × 740 CSS-pixel viewport the cue screen had no horizontal overflow and all measured buttons were at least 48 CSS pixels high. This is desktop responsive emulation, not an iPhone check.
- Remaining acceptance checks include learner walkthrough/review, actual phone/audio behaviour, explicit text-scaling testing and storage-quota fault injection. No long-term persistence or learning-outcome claim follows from these checks.

## Observed design findings and limits

- During author review, the second acknowledgement cue was strengthened from a bare “That's …” to “That's a good […]” with an argument-specific purpose. This avoids guessing the adjective. The initial identifying cue, rather than rescue help, carries that distinction.
- Browser walkthroughs confirmed that full-model help survives reload and stays model-assisted. A shown target word is labelled usage; alternative wording and an unclear cue do not trigger a memory-failure outcome. These are implementation checks, not learner usability approval.
- The pack is **author-checked by Codex**, not independently reviewed by a human. Its candidate cues still need this learner's review, particularly where several natural alternatives are acknowledged. No runtime AI provider calls, speech recognition or automatic assessment are used.
- Model audio is explicitly pending for every realization. All prototype instructions say to read the model and speak aloud. No fake audio button or browser TTS stands in for checked model audio.
- English is a fixture choice, not an agreed limit on launch languages. A Unicode structural test uses Serbian text; it is not a reviewed Serbian teaching pack.
- No microphone, headphones, iPhone Safari, installed PWA, locked-screen playback, offline asset cache, quota-failure injection, long-term retention or learning efficacy has been verified. The actual-device gate remains pending.

## Next work

Use the [seven walkthroughs](../../design/p1-walkthrough.md) to get concrete learner feedback and refine cue clarity and help/result wording. Build P1.3's audio/storage probe with real model assets and private HTTPS, collect the actual phone capability report, then make P1.4 decisions before the production foundation.

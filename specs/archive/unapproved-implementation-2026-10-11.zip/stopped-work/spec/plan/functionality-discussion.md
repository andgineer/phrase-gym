# Phrase Gym — current state and open choices

Updated 2026-10-11.

## Baseline and status

- **Agreed:** [targeted drilling](../decision-targeted-drilling.md), plus the name Phrase Gym.
- **Baseline clarification:** before implementation, no Phrase Gym prototype existed. Earlier sketches and legacy files do not count as completed milestones.
- **Current work:** implementation authorized in the new `~/projects/phrase-gym` scaffold. P1 has a text-only prototype and fixture pack for review; P2–P6 are not started. See [first implementation evidence](evidence/p1-first-slice.md).

Start with the [implementation roadmap](implementation-plan.md) and [P1 prototyping](01-prototyping.md). The [architecture](../architecture.md) recommends a mobile PWA, small Python backend and durable target-level storage, subject to prototype findings. Detailed contracts cover [learning behaviour](../architecture/learning-engine.md) and [data/API boundaries](../architecture/data-contracts.md).

The [functional description](../functional-description.md) remains a draft of supporting scope. [Interaction design](../design/interaction-design.md) describes work to produce during prototyping, not an approved layout. The [research record](../research-memorizing-phrases.md) distinguishes evidence from product choices.

## Choices to resolve through the plan

| Choice | Proposed starting point | Evidence/decision point |
|---|---|---|
| Exact session interface | Prototype complete user-visible flows from the agreed decision. | P1 user walkthrough; no inherited screen approval. |
| Cue selection and mask changes | Reviewed meaningful chunks, candidate alternatives checked, deterministic rotation initially. | P1 cue pack and later P5 generated-content evaluation. |
| Review eligibility and intervals | One schedule per target, explicit support/coverage, replaceable conservative policy. | P1 outcome review, P3 correctness tests and P6 delayed pilot. |
| Client platform and recording | Mobile PWA and optional foreground recording. | P1 actual-phone audio probe; P4 reliability checks. |
| First inputs | Phrases and word/frame targets share manual import; live echo-words handoff follows the core. | Confirm first-release scope in P1; implement P5. |
| Languages and supporting features | Explicit language metadata from the start; choose initial content languages, recording retention and help controls. | P1/P4. |
| Host and access | Private HTTPS; measure the named Oracle VM and laptop options. | P6, after there is a build to measure. |

Automatic speech grading, eyes-free/locked-screen operation and old Anki migration are separate possible additions. Open-ended AI conversation and free role-play remain excluded entirely. Additional course enrolment is not authorized and is not needed for these plans.

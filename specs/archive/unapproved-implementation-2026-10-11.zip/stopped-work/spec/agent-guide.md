# Phrase Gym — development instructions

The user has authorized implementation in `~/projects/phrase-gym`, using the scaffold they created. The learning baseline is [targeted drilling](decision-targeted-drilling.md). Follow the [roadmap](plan/implementation-plan.md) and the current [P1 report](plan/evidence/p1-first-slice.md). Read the applicable phase and architecture documents before changing their contracts.

- Reply and write project development documents in English. Learning material stays in its target language; translations are on request.
- Preserve the scaffold: `src/phrase_gym`, hatchling, uv, rich-click, pytest, Invoke, CI and documentation workflows. Replace templates with working Phrase Gym behaviour.
- P1 is prototyping, not the production foundation. The first text-only walkthrough and author-checked pack require learner review. Audio/device checks and the P1.4 decision remain pending. Proposed stack and scheduling parameters are not accepted merely because a document recommends them.
- Train selected words, constructions, fixed expressions and prepared dialogues. Open-ended AI conversation and free role-play are excluded entirely.
- Introduce expressions before recall; use sufficient phrase-specific meaningful anchors and deliberately varied masks. Require the whole phrase aloud. Do not punish valid alternative language or ambiguous prompts.
- Record support used. Model reading, immediate repair, partial-cue recall and shown-word usage are distinct evidence. Keep one target identity across cues and dialogue appearances.
- All development docs, decisions, research and evidence belong under `spec/`. `docs/` is the existing user-documentation site. `spec/history/` is archival data, not current instructions.
- Run Python tests, the prototype reducer tests, lint/type checks and relevant browser walkthroughs after behaviour changes. `uv run inv test` runs the Python and JavaScript suites. `uv run inv pre` uses pre-commit once Git is initialized; do not initialize Git just to run it. Record equivalent direct checks and any limitation while this directory has no Git metadata.
- Do not initialize Git, commit, publish, enroll in courses or switch echo-words output unless requested. The vault is read-only source material for this project; write code and generated state outside it.
- `../phrase-shadowing/` contains the old trainer; it is neither a Phrase Gym prototype nor progress to migrate. Its README documents the original source format. Follow echo-words' own instructions if that separate project is changed later.

Read [architecture](architecture.md), [learning engine](architecture/learning-engine.md), [data contracts](architecture/data-contracts.md), [cue review](design/p1-cue-review.md) and [research limits](research-memorizing-phrases.md) as needed. No research result certifies this complete workflow or AI-generated content.

# Decision: name and planning baseline

Name selected 2026-10-10; baseline clarified 2026-10-11.

- The app is named **Phrase Gym**. On 2026-10-11 the user moved the new app into `~/projects/phrase-gym`, using their Python package scaffold. Development documentation lives in its `spec/` folder; phrase-shadowing retains the old trainer and tooling.
- The accepted learning-behaviour decision is [targeted drilling](decision-targeted-drilling.md).
- The user requested architecture and implementation plans, and clarified that **prototyping must be included as work to do**. At that point there was no Phrase Gym prototype or implementation baseline. The first P1 text prototype has since been implemented for review; it is not an approved design or production milestone.
- Earlier interface sketches, existing source files and legacy tooling do not count as completed prototyping. No migration of existing progress is assumed.
- The [architecture](architecture.md), [implementation roadmap](plan/implementation-plan.md), stack and supporting feature choices are proposals to validate; the naming/design request does not automatically approve them or authorize deployment.

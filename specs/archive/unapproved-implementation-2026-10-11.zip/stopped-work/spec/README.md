# Phrase Gym development

The app lives in `~/projects/phrase-gym`, using the user's Python package scaffold. The old phrase-shadowing trainer remains a separate project.

- [Accepted drilling behaviour](decision-targeted-drilling.md)
- [Name and project baseline](decision-name-and-design.md)
- [Implementation roadmap](plan/implementation-plan.md) and [P1 status/evidence](plan/evidence/p1-first-slice.md)
- [Architecture](architecture.md), [learning engine](architecture/learning-engine.md), [data contracts](architecture/data-contracts.md)
- [Prototype walkthrough guide](design/p1-walkthrough.md) and [cue review](design/p1-cue-review.md)
- [Research and its limits](research-memorizing-phrases.md)
- [Open product choices](plan/functionality-discussion.md)
- [Development instructions](agent-guide.md)
- [Migration record](plan/evidence/project-move.md)

`history/` contains archived source documents and the original discussion export. They are historical evidence, not the current specification or instructions.

# Phrase Gym — agent instructions

`AGENTS.md` is a symlink to this file.

## Current baseline

The app is named **Phrase Gym**. The agreed learning-behaviour baseline is `spec/decision-targeted-drilling.md`.

On 2026-10-11 the user clarified: **there are no Phrase Gym prototypes; prototyping must be part of the plan**. Do not count earlier conversation sketches, `index.html`, `phrases.py` or legacy tooling as completed prototype or implementation work. Do not assume existing app progress exists or needs migration.

Architecture and implementation planning are authorized. The proposed stack, layouts, scheduling parameters, supporting features and hosting are not separately approved just because they appear in a plan. The next implementation phase is P1 prototyping; all implementation phases are currently not started. Do not skip it and present a production scaffold as the agreed design.

## Read in this order

1. `spec/decision-targeted-drilling.md` — accepted behaviour and product boundary.
2. `spec/plan/implementation-plan.md` — roadmap, scope and current status; follow its links to the relevant phase plan.
3. `spec/architecture.md` — recommended architecture; `spec/architecture/learning-engine.md` and `spec/architecture/data-contracts.md` provide the detailed proposed contracts.
4. `spec/plan/functionality-discussion.md` — remaining product choices; `spec/decision-name-and-design.md` records naming and the baseline clarification.
5. `spec/functional-description.md`, `spec/design/interaction-design.md` — draft/candidate supporting scope and design work to produce; not additional accepted requirements.
6. `spec/research-memorizing-phrases.md` — evidence and its limits. Raw `discussion/` is historical context only, not the current specification.

## Working with the user

- Reply and write project documents in English. Learning material stays in the target language; translations and explanations are on request.
- For choices, explain the user-visible effect, compare concrete alternatives and state a recommendation. Do not treat a recommendation as accepted.
- Drill known expressions, words in useful phrases and specific dialogues. Open-ended AI conversation and free role-play are excluded, including as a later direction.
- Choose enough meaningful cue material to identify the target in context; chunks can come from anywhere in the expression. Support different hidden chunks across repetitions. The learner says the entire phrase. Random gaps and first-letter puzzles remain rejected.
- A broad situation prompt cannot demand one exact answer. Ambiguous cues and valid alternative wording are not automatic memory failures. Record the support used; visible-model repetition is not independent recall.
- Keep one learning target and one schedule across masks, examples and dialogue appearances.
- Use prototypes to establish interaction clarity and device feasibility. Research findings, engineering assumptions and observed prototype results must remain distinguishable.
- Code, scripts and tooling belong under `~/projects/`, never in the Obsidian vault. The vault is synced by obsidian-git: do not commit, push, switch branches or use `git mv` there.
- This project is not a git repository; do not initialize or commit unless asked. Preserve existing files unless the task actually calls for changing them.

## Related material

- Vault phrase notes: `~/obsidian/kb/languages/english/фразы/`; audio is in `_assets/`. A future importer reads explicitly selected source material and writes its own state outside the vault.
- echo-words: `~/projects/echo-words`. Its code is a reference for language analysis and intake. A future integration must use a durable export contract; its recent history is not a permanent content database. Follow its own instructions if changing it.
- `README.md`, `index.html` and `phrases.py` describe legacy source tooling. They are not the Phrase Gym architecture, an accepted prototype, or evidence that any roadmap stage is complete.
- EPAM lessons 1–2 were previously available; enrolling in lessons 3–14 was not authorized. Course acquisition is not part of architecture or implementation planning.

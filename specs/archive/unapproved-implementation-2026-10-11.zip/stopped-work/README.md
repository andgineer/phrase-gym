# Phrase Gym

A language trainer for automatic use of words and phrases through guided recall, spaced repetition, and targeted dialogue drills.

Development is at **P1: prototyping**. The current runnable slice is a text-only walkthrough with 12 learning targets, 24 reviewed-by-author cue candidates and two prepared dialogues. Say complete phrases aloud and compare them with the model. No audio, speech assessment, due-review scheduling or production progress storage is implemented yet.

## Try the prototype

Requires Python 3.12+ and uv. Run from this checkout:

```bash
uv sync --locked
uv run phrase-gym validate-materials
uv run phrase-gym prototype
```

Open [the local prototype](http://127.0.0.1:8765). Use `--port` to choose another local port, or `--project-dir` when running outside the checkout. Ctrl+C stops the server. The server exposes only the prototype assets and fixture pack.

The walkthrough saves a temporary checkpoint in this browser, including help already shown. It does not create real learning progress. Choose “Clear this browser's walkthrough” to remove it. Recordings are not collected.

## Development

Keep the existing Python src layout, hatchling/uv packaging, Click command, pytest, Invoke and documentation tooling. Disposable browser code is under `prototypes/drill-flow/`; fixtures are under `fixtures/p1/`. The eventual production stack remains a proposal to validate.

```bash
uv run inv test              # Python plus prototype JavaScript tests; needs Node 20+
uv run inv pre               # pre-commit checks once this checkout has Git metadata
uv run inv build-docs        # existing documentation build
uv run phrase-gym --help
```

All development decisions, architecture, plans and evidence live in [spec/](spec/README.md). Start with the [roadmap](spec/plan/implementation-plan.md) and [prototype walkthrough](spec/design/p1-walkthrough.md). `docs/` is the scaffold's user-documentation site. No package release or hosted app is implied by the scaffold's publishing workflows.

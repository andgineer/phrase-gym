#!/usr/bin/env python3
"""Tooling for the phrase trainer.

  fetch LESSON_ID URLS_FILE   download course audio and cut the spoken number off the start
  split FILE                  split a two-speaker exchange at its longest pause into FILEa / FILEb
  tts [--force]               synthesize every missing *-tts.mp3 the lesson notes embed (neural voices via edge-tts)
  build OUT_DIR               parse lesson notes and assemble the publishable page in OUT_DIR
"""
import argparse
import array
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
NOTES = Path(os.environ.get("PHRASES_NOTES", Path.home() / "obsidian/kb/languages/english/фразы"))
ASSETS = NOTES / "_assets"

RATE = 16000
FRAME_MS = 10
SPEECH_DB = 35  # a frame is speech when within this many dB of the file's peak
ONSET_DB = 50  # softer threshold used to walk back to the true start of the phrase
MIN_GAP_MS = 250
LEAD_MS = 50
MAX_NUMBER_MS = 1300
WAVE_FPS = 25
DEFAULT_VOICES = {"A": "en-GB-RyanNeural", "B": "en-GB-SoniaNeural"}
TARGET_LUFS = -20  # loudness of the course actors' recordings, so synthetic lines sit at the same level


def envelope(path):
    raw = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(path), "-f", "s16le", "-ac", "1", "-ar", str(RATE), "-"],
        capture_output=True, check=True,
    ).stdout
    x = array.array("h")
    x.frombytes(raw)
    hop = RATE * FRAME_MS // 1000
    db = []
    for i in range(len(x) // hop):
        chunk = x[i * hop:(i + 1) * hop]
        energy = sum(v * v for v in chunk) / hop
        db.append(10 * math.log10(energy / 32768 ** 2 + 1e-12))
    return db


def gaps(db):
    """Silent runs of at least MIN_GAP_MS between speech, as (start, end) frame indexes."""
    peak = max(db)
    speech = [d > peak - SPEECH_DB for d in db]
    first = speech.index(True)
    last = len(speech) - 1 - speech[::-1].index(True)
    out, i = [], first
    while i <= last:
        if speech[i]:
            i += 1
            continue
        j = i
        while j <= last and not speech[j]:
            j += 1
        if (j - i) * FRAME_MS >= MIN_GAP_MS:
            out.append((i, j))
        i = j
    return first, last, out


def soft_onset(db, gap_start, onset):
    peak = max(db)
    k = onset
    while k > gap_start and db[k - 1] > peak - ONSET_DB:
        k -= 1
    return k


def encode(src, dst, start=None, end=None):
    cmd = ["ffmpeg", "-v", "error", "-y", "-i", str(src)]
    if start is not None:
        cmd += ["-ss", f"{start:.3f}"]
    if end is not None:
        cmd += ["-to", f"{end:.3f}"]
    cmd += ["-af", "afade=t=in:d=0.01", "-ac", "1", "-c:a", "libmp3lame", "-q:a", "2", str(dst)]
    subprocess.run(cmd, check=True)


def number_cut(db):
    """Seconds where the phrase starts after the spoken number, or None when no number is detected."""
    first, _, found = gaps(db)
    if not found:
        return None
    gap_start, onset = found[0]
    if (gap_start - first) * FRAME_MS > MAX_NUMBER_MS:
        return None
    start = soft_onset(db, gap_start, onset) * FRAME_MS - LEAD_MS
    return max(start, gap_start * FRAME_MS) / 1000


def cmd_fetch(args):
    ASSETS.mkdir(exist_ok=True)
    lines = [l.split() for l in Path(args.urls).read_text().splitlines() if l.strip()]
    problems = 0
    with tempfile.TemporaryDirectory() as tmp:
        for n, url in lines:
            raw = Path(tmp) / f"{n}.mp3"
            subprocess.run(["curl", "-sSfL", "-o", str(raw), url], check=True)
            db = envelope(raw)
            cut = number_cut(db)
            dst = ASSETS / f"{args.lesson}-{int(n):02d}.mp3"
            if cut is None:
                problems += 1
                print(f"{dst.name}: no spoken number found, copied untrimmed — check by ear")
                encode(raw, dst)
                continue
            encode(raw, dst, start=cut)
            print(f"{dst.name}: cut {cut:.2f}s of {len(db) * FRAME_MS / 1000:.2f}s")
    return 1 if problems else 0


def cmd_split(args):
    src = Path(args.file)
    db = envelope(src)
    _, _, found = gaps(db)
    if not found:
        sys.exit(f"{src.name}: no pause to split at")
    gap_start, onset = max(found, key=lambda g: g[1] - g[0])
    mid = (gap_start + soft_onset(db, gap_start, onset)) / 2 * FRAME_MS / 1000
    encode(src, src.with_name(src.stem + "a.mp3"), end=mid)
    encode(src, src.with_name(src.stem + "b.mp3"), start=mid)
    print(f"{src.name}: split at {mid:.2f}s")


def waveform(path):
    db = envelope(path)
    amp = [10 ** (d / 20) for d in db]
    peak = max(amp)
    per = 1000 // WAVE_FPS // FRAME_MS
    return [round((max(amp[i:i + per]) / peak) ** 0.6, 2) for i in range(0, len(amp), per)]


def duration(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)],
        capture_output=True, text=True, check=True,
    ).stdout
    return round(float(out), 2)


EMBED = re.compile(r"!\[\[([^\]|]+\.mp3)\]\]")
BOLD = re.compile(r"\*\*(.+?)\*\*")
COMMENT = re.compile(r"<!--(.*?)-->")
DIALOG_LINE = re.compile(r"-d\d+-\d+$")


def front_matter(text):
    meta = {}
    if text.startswith("---\n"):
        head, _, text = text[4:].partition("\n---\n")
        for line in head.splitlines():
            key, _, value = line.partition(":")
            meta[key.strip()] = value.strip().strip('"')
    return meta, text


def audio_ref(name, audio):
    audio.setdefault(name, ASSETS / name)
    return "audio/" + name


def phrase_of(name):
    return re.sub(r"[a-z]$", "", Path(name).stem.removesuffix("-tts"))


def lesson_notes():
    """Lesson notes in their `порядок` order, so the trainer introduces the current course before extras."""
    notes = [(front_matter(n.read_text())[0], n) for n in sorted(NOTES.glob("*.md"))]
    return [n for meta, n in sorted(notes, key=lambda x: int(x[0].get("порядок", 99))) if "id" in meta]


def parse_lesson(path, audio):
    meta, body = front_matter(path.read_text())
    lesson_id = meta["id"]
    lesson = {"id": lesson_id, "title": meta.get("урок", path.stem), "course": meta.get("курс", ""), "note": path.stem}
    phrases, dialogs = [], []
    section = topic = None
    current = None
    for raw in body.splitlines():
        line = raw.rstrip()
        if line.startswith("## "):
            section, topic, current = line[3:].strip().lower(), None, None
            continue
        if line.startswith("### "):
            topic = line[4:].strip()
            current = None
            if section == "диалоги":
                current = {"id": f"{lesson_id}-d{len(dialogs) + 1}", "lesson": lesson_id, "title": topic, "lines": []}
                dialogs.append(current)
            continue
        if section == "фразы":
            m = re.match(r"^(\d+)\.\s+(.+)$", line)
            if m:
                current = {"id": f"{lesson_id}-{int(m[1]):02d}", "lesson": lesson_id, "n": int(m[1]),
                           "topic": topic, "text": m[2].strip(), "cue": "", "audio": None}
                phrases.append(current)
            elif current and (e := EMBED.search(line)):
                current["audio"] = audio_ref(e[1], audio)
            elif current and (r := re.match(r"^\s+\*(.+)\*$", line)):
                current["cue"] = r[1].strip()
        elif section == "диалоги" and current is not None:
            m = re.match(r"^- ([A-Z]):\s+(.+)$", line)
            if not m:
                continue
            text = COMMENT.sub("", m[2])
            entry = {"who": m[1]}
            if e := EMBED.search(text):
                entry["audio"] = audio_ref(e[1], audio)
                if not DIALOG_LINE.search(ref := phrase_of(e[1])):
                    entry["phrase"] = ref
                text = EMBED.sub("", text).strip()
            b = BOLD.search(text)
            if b and "phrase" in entry:
                entry.update(pre=text[:b.start()].strip(), text=b[1].strip(), post=text[b.end():].strip())
            else:
                entry["text"] = BOLD.sub(r"\1", text).strip()
            current["lines"].append(entry)
    return lesson, phrases, dialogs


def loudness(path):
    err = subprocess.run(["ffmpeg", "-v", "info", "-i", str(path), "-af", "ebur128", "-f", "null", "-"],
                         capture_output=True, text=True, check=True).stderr
    return float([l for l in err.splitlines() if l.strip().startswith("I:")][-1].split()[1])


def synthesize(text, voice, dst):
    with tempfile.TemporaryDirectory() as tmp:
        raw = Path(tmp) / "raw.mp3"
        subprocess.run(["uvx", "--from", "edge-tts", "edge-tts", "--voice", voice, "--text", text,
                        "--write-media", str(raw)], check=True, capture_output=True)
        gain = TARGET_LUFS - loudness(raw)
        trim = "silenceremove=start_periods=1:start_threshold=-50dB"
        chain = (f"{trim},areverse,{trim},areverse,adelay=delays={LEAD_MS}:all=1,apad=pad_dur=0.15,"
                 f"volume={gain:.1f}dB,alimiter=limit=0.95")
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(raw), "-af", chain, "-ar", "44100", "-ac", "1",
                        "-c:a", "libmp3lame", "-q:a", "2", str(dst)], check=True)


def tts_jobs(note):
    """Text and voice for every clip a note embeds: a phrase's own text, else its first dialog line."""
    meta, body = front_matter(note.read_text())
    voices = dict(DEFAULT_VOICES)
    voices.update({side: meta[f"голос {side.lower()}"] for side in voices if f"голос {side.lower()}" in meta})
    jobs = {}
    section = phrase = None
    for line in body.splitlines():
        if line.startswith("## "):
            section, phrase = line[3:].strip().lower(), None
        elif section == "фразы" and (m := re.match(r"^(\d+)\.\s+(.+)$", line)):
            phrase = m[2].strip()
        elif section == "фразы" and phrase and (e := EMBED.search(line)):
            jobs.setdefault(e[1], [phrase, None])
        elif section == "диалоги" and (m := re.match(r"^- ([A-Z]):\s+(.+)$", line)) and (e := EMBED.search(m[2])):
            override = COMMENT.search(m[2])
            voice = override[1].replace("voice:", "").strip() if override else voices[m[1]]
            text = BOLD.sub(r"\1", EMBED.sub("", COMMENT.sub("", m[2]))).strip()
            job = jobs.setdefault(e[1], [text, None])
            job[1] = job[1] or voice
    return {name: (text, voice or voices["A"]) for name, (text, voice) in jobs.items()}


def cmd_tts(args):
    made = 0
    for note in lesson_notes():
        for name, (text, voice) in tts_jobs(note).items():
            dst = ASSETS / name
            if not name.endswith("-tts.mp3") or (dst.exists() and not args.force):
                continue
            synthesize(text, voice, dst)
            made += 1
            print(f"{name}  {voice}  {text}")
    print(f"{made} clips synthesized")


def cmd_build(args):
    audio = {}
    lessons, phrases, dialogs = [], [], []
    for note in lesson_notes():
        lesson, p, d = parse_lesson(note, audio)
        lessons.append(lesson)
        phrases += p
        dialogs += d
    missing = [str(f) for f in audio.values() if not f.exists()]
    if missing:
        sys.exit("missing audio: " + ", ".join(missing))
    waves = {"audio/" + name: {"wave": waveform(f), "dur": duration(f), "tts": name.endswith("-tts.mp3")}
             for name, f in audio.items()}
    known = {p["id"] for p in phrases}
    for d in dialogs:
        for line in d["lines"]:
            if "phrase" in line and line["phrase"] not in known:
                sys.exit(f"{d['id']}: line refers to unknown phrase {line['phrase']}")
    data = {"lessons": lessons, "phrases": phrases, "dialogs": dialogs, "audio": waves}
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    out = Path(args.out)
    (out / "audio").mkdir(parents=True, exist_ok=True)
    page = (HERE / "index.html").read_text().replace("__PHRASES__", payload)
    (out / "index.html").write_text(page)
    for name, f in audio.items():
        shutil.copy2(f, out / "audio" / name)
    print(f"{len(lessons)} lessons, {len(phrases)} phrases, {len(dialogs)} dialogs, {len(audio)} audio files -> {out}")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("fetch")
    f.add_argument("lesson")
    f.add_argument("urls", help="file with lines: <number> <audio url>")
    s = sub.add_parser("split")
    s.add_argument("file")
    t = sub.add_parser("tts")
    t.add_argument("--force", action="store_true", help="re-synthesize clips that already exist")
    b = sub.add_parser("build")
    b.add_argument("out")
    args = parser.parse_args()
    sys.exit({"fetch": cmd_fetch, "split": cmd_split, "tts": cmd_tts, "build": cmd_build}[args.cmd](args))


if __name__ == "__main__":
    main()

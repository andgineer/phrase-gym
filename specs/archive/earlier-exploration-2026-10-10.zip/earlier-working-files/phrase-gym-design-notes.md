# Phrase Gym — interaction design

First design proposal, 2026-10-10. The name and move into design are accepted; these layouts and interaction details are proposals for review. The [drilling decisions](../decision-targeted-drilling.md) remain the learning constraints.

## Direction

Design first for the iPhone and short daily sessions. Use a calm, compact interface: warm neutral surfaces, deep green actions, generous touch targets and large phrase text. Use sans-serif type for controls and a readable serif for expressions. Follow the device's light or dark appearance.

The primary screen gives one spoken task and a clear next action. Keep context, cue, help and model comparison close to the phrase. The app's identity comes from useful practice, not scores, streaks or a chat feed.

## Navigation

| Section | What the learner can do |
|---|---|
| Practice | Start the prepared daily session; see its topics and the number of expressions to review or learn. |
| Phrases | Find fixed expressions and words in phrases; open meaning, purpose and source; practise a selected item. |
| Dialogues | Read a short prepared exchange, see its target expressions, then rehearse the learner's side. |

During a session, replace app navigation with an exit action and session progress. An exit returns to Practice in this concept; pause/resume behaviour still needs design. Home previews name topics rather than display complete answers immediately before review.

## Core session screens

| Screen | What is visible | Learner action and next state |
|---|---|---|
| New expression | Full phrase, purpose, model audio control and optional partner line | Listen, read and say it; choose **Try with a cue**. |
| Recall | Purpose, enough phrase-specific material to identify the target, and **Say the whole phrase aloud** | Say the whole phrase, then choose **I've said it**. |
| Help | **Show the phrase** and an on-demand meaning explanation | Full-phrase help reveals the model and marks the attempt as supported. |
| Check | Complete model phrase, with the previously hidden chunk emphasized | Self-report **Matched the phrase**, or **I need another try**. This is not automatic speech assessment. |
| Repair | Full model and an instruction to repeat the entire phrase | Repeat, then continue; the expression is included among items needing another recall. |
| Later recall | The same target can have another meaningful chunk hidden | Speak the whole phrase again. This is another attempt on the same learning target. |
| Session result | One entry per expression and a description of the support used | Revisit difficult expressions, open a dialogue or return to Practice. |

No answer timer or automatic correctness score is proposed. The result distinguishes practice with cues, model-assisted work and introduction of new material; it does not label any of these independent mastery.

**I used different wording** opens a separate route: practise the selected expression, or flag **The cue was unclear**. A flagged cue is shown as needing review, not as a memory failure. The interface does not claim that it has checked whether the alternative was good English. Uncertain recording and recognition still need dedicated states before automatic assessment is introduced.

## Two layouts to compare

| Layout | Recall screen | Best use |
|---|---|---|
| **Focus — recommended default** | A short purpose above one prominent phrase card; help immediately below; one main action at the bottom. | Routine daily recall with minimal reading. |
| **In context** | The partner's preceding line remains visible above the learner's cued response, with separate speaker labels. | When the preceding exchange helps establish use or when practising a dialogue. |

Both use the same learning targets, cue rules and review history. The context variant is a prepared exchange, not an AI chat. The preview also allows phrase-size adjustment and showing or hiding the partner line; these are design controls, not proposed app settings.

## Dialogue flow

First show the complete short dialogue and identify target expressions. **Rehearse my lines** starts the learner's side: partner line, target-specific cue, spoken response and comparison. Supporting lines remain available to read. A dialogue turn contributes to the same target history as individual practice.

An isolated difficult-turn practice action remains to be designed. The preview demonstrates a repair within the turn and revisiting difficult targets after the session.

## Voice, help and collection

Model audio is placed beside introduction and comparison. Recording remains a desired capability: an optional **Record a take** action should belong to the current attempt, with model and learner playback available at comparison. Recording permission, microphone failure and recognition uncertainty need dedicated states; the preview does not record, play or grade audio.

Phrase details show the complete expression, its purpose, meaning and source collection. Search and Due/New filters demonstrate finding material, with both fixed phrases and a word-in-phrase item. Personal notes, importing sources and recording history need subsequent design passes. Translations remain on request; the initial interface is English.

## Preview scope

The in-conversation clickable concept covers Practice, a four-attempt sample session, model help, meaning help, repair, changing the hidden chunk, session results, the phrase collection and details, and two specific dialogues. Sample expressions, counts and progress are illustrative, not the user's current learning history.

The sample returns to **How has your day been so far?** after intervening items, hiding **How has** first and **your day** later. Other illustrative targets are **Would you mind walking me through it?** and **raise a concern** in a sentence. These are interface examples; each production cue still requires checking against plausible alternatives.

This is an interaction concept, not an implemented trainer. The review algorithm, cue generation, real audio and recording, hands-free mode, integrations and deployment remain outside this preview.

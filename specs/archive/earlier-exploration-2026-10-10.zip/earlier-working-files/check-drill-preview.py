from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={'width': 800, 'height': 1050}, color_scheme='light')
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.goto('file:///private/tmp/drill-session-preview.html')
    frame = page.frame_locator('iframe')
    frame.locator('#drill-session-name').wait_for()
    print('Initial:', frame.locator('#drill-session-name').inner_text())
    frame.locator('#drill-next').click()
    frame.locator('#drill-next').click()
    assert frame.locator('#drill-answer').is_hidden()
    frame.locator('#drill-hint-button').click()
    assert frame.locator('#drill-hint').is_visible()
    frame.locator('#drill-reveal-button').click()
    assert 'I suggest' in frame.locator('#drill-answer-text').inner_text()
    assert frame.locator('#drill-answer').is_visible()
    page.screenshot(path='/private/tmp/drill-session-desktop.png', full_page=True)
    for session in ['word', 'dialogue', 'review']:
        frame.locator('[data-session="' + session + '"]').click()
        assert frame.locator('#drill-step-count').inner_text().startswith('Moment 1')
        frame.locator('#drill-next').click()
        print('Session:', frame.locator('#drill-session-name').inner_text())
    frame.locator('[data-session="dialogue"]').click()
    page.set_viewport_size({'width': 352, 'height': 1150})
    page.screenshot(path='/private/tmp/drill-session-mobile.png', full_page=True)
    child = page.frames[1]
    overflow = child.evaluate('document.documentElement.scrollWidth > document.documentElement.clientWidth')
    print('Mobile horizontal overflow:', overflow)
    print('Page errors:', errors)
    assert not overflow and not errors
    browser.close()

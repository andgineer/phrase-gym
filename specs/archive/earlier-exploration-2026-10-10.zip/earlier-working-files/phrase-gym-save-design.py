from pathlib import Path
import hashlib
import json

root=Path('/Users/andrei_sorokin2/projects/phrase-shadowing')
temp=Path('/private/tmp')
claude=(root/'CLAUDE.md').read_text()
plan=(root/'spec/plan/functionality-discussion.md').read_text()
functional=(root/'spec/functional-description.md').read_text()

def replace_once(text, old, new):
    if text.count(old)!=1:
        raise SystemExit('Expected text changed; inspect before updating: '+old)
    return text.replace(old,new,1)

claude=replace_once(claude,'# phrase-shadowing — agent instructions','# Phrase Gym — agent instructions')
claude=replace_once(claude,'**A new app being designed** — a trainer','**A new app being designed, Phrase Gym** — a trainer')
claude=replace_once(claude,'It is in phase 1. Do not start design or hosting until the user settles the functionality.','The user selected the name Phrase Gym and explicitly moved the work into phase 2 on 2026-10-10. Design exploration is authorized while remaining functional details are resolved. Deployment is still a later phase.')
claude=replace_once(claude,'1. `spec/plan/functionality-discussion.md` — current state, remaining functional choices and deferred work.','1. `spec/plan/functionality-discussion.md` — current phase, accepted name, remaining choices and deferred work. Then read `spec/decision-name-and-design.md` and `spec/design/interaction-design.md` for the design status and first proposal.')
plan=replace_once(plan,'# Functionality — current decisions and remaining work','# Phrase Gym — current design and remaining choices')
plan=replace_once(plan,'Updated 2026-10-10. Phase 1: **functionality → design → deploy**.','Updated 2026-10-10. Phase 2: functionality → **design** → deploy. The user selected **Phrase Gym** and explicitly requested starting design; unresolved functional details remain open rather than blocking design exploration.')
plan=replace_once(plan,'## Current documents\n','## Current documents\n\n- [Name and design-phase decision](../decision-name-and-design.md): accepted name and authorization to begin design.\n- [Interaction design](../design/interaction-design.md): the first mobile-first proposal and its Focus / In context layouts; not yet approved.\n')
plan=replace_once(plan,'Next: work through concrete sessions using the accepted cue rules, resolve these choices, and obtain agreement on the complete functional description. Do not reopen excluded product directions.','Next: inspect the clickable design, refine its sessions and screens, and resolve the remaining choices through concrete interactions. The first proposal recommends Focus for daily recall and a visible partner line for dialogue rehearsal. Visual details and the complete first-version feature set still need agreement. Do not reopen excluded product directions.')
functional=replace_once(functional,'# Functional description — phrase and word trainer','# Phrase Gym — functional description')
functional=replace_once(functional,'Work remains in functionality planning. Design and deployment follow agreement on the remaining functional choices.','The user authorized design exploration on 2026-10-10; see the [interaction design](design/interaction-design.md). Remaining functional choices stay open during design. Deployment remains a later phase.')
updates={
 'CLAUDE.md':claude,
 'spec/plan/functionality-discussion.md':plan,
 'spec/functional-description.md':functional,
 'spec/decision-name-and-design.md':(temp/'phrase-gym-name-decision.md').read_text(),
 'spec/design/interaction-design.md':(temp/'phrase-gym-design-notes.md').read_text(),
}
protected={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['index.html','phrases.py','README.md']}
for rel,content in updates.items():
    p=root/rel
    if rel in ['spec/decision-name-and-design.md','spec/design/interaction-design.md'] and p.exists():
        raise SystemExit('New design file already exists; inspect before overwriting.')
for rel,content in updates.items():
    p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
    print('Saved '+rel)
assert (root/'AGENTS.md').is_symlink()
for rel,digest in protected.items():
    assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest
import re
for rel in updates:
    p=root/rel
    for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
        if '://' not in link: assert (p.parent/link.split('#')[0]).exists(),link
print('Verified local links; prototype files and agent symlink preserved.')

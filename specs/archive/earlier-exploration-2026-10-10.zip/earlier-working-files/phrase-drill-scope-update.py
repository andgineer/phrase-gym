import json
from pathlib import Path

root = Path("/Users/andrei_sorokin2/projects/phrase-shadowing")
changes = json.loads(Path("/private/tmp/phrase-drill-scope-changes.json").read_text())
prepared = []
for relative, replacements in changes.items():
    path = root / relative
    before = path.read_text()
    after = before
    for old, new in replacements:
        if after.count(old) != 1:
            raise SystemExit(f"Expected one exact match in {relative}: {old[:100]!r}")
        after = after.replace(old, new, 1)
    prepared.append((path, before, after))
for path, before, after in prepared:
    if path.read_text() != before:
        raise SystemExit(f"File changed during preparation: {path}")
for path, before, after in prepared:
    path.write_text(after)
    print(f"Updated {path.relative_to(root)}")

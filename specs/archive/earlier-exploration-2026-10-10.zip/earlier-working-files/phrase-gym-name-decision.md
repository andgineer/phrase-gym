# Decision: app name and design phase

Accepted 2026-10-10.

- The app is named **Phrase Gym**.
- The user explicitly requested moving into app design. Design exploration is now authorized; it need not wait for every remaining functional detail to be settled.
- The [targeted-drilling decisions](decision-targeted-drilling.md) remain in force. Moving into design does not approve every first-version feature, a visual direction, an implementation stack or deployment.
- The first [interaction design](design/interaction-design.md) is a proposal to inspect and refine.

The project directory remains `phrase-shadowing`; the existing daily-use prototype and its progress are preserved.


(() => {
  const root = document.getElementById('phrase-gym-design');
  const icon = name => `<i data-lucide="${name}" aria-hidden="true"></i>`;
  const escape = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const items = {
    day: { text: 'How has your day been so far?', label: 'Checking in', type: 'Phrase', purpose: 'Ask about their day up to now.', partner: 'Hi! Good to see you.', status: 'Due', source: 'Small talk', explanation: 'A friendly way to ask how someone’s day is going. “So far” means up to this moment.', masks: [['', 'How has', ' your day been so far?'], ['How has ', 'your day', ' been so far?']] },
    walkthrough: { text: 'Would you mind walking me through it?', label: 'Asking for an explanation', type: 'Phrase', purpose: 'Ask someone to explain a process.', partner: 'We have a new way to submit expenses.', status: 'New', source: 'At work', explanation: '“Walk someone through” means to explain something step by step. This is a polite request.', masks: [['Would you mind walking ', 'me through it', '?']] },
    concern: { text: 'I’d like to raise a concern about the deadline.', label: 'Raising a concern', type: 'Word in a phrase', purpose: 'Flag a worry about the deadline.', partner: 'We’d like to launch on Friday.', status: 'Due', source: 'At work', explanation: '“Raise a concern” means to bring a worry to someone’s attention so it can be discussed.', masks: [['I’d like to raise ', 'a concern', ' about the deadline.']] }
  };
  const dialogues = {
    meeting: { title: 'Before a meeting', subtitle: 'Check in, then ask for an explanation', lines: [{who:'Alex',text:'Hi! Good to see you.'},{who:'You',item:'day'},{who:'Alex',text:'Busy morning? I’ve just finished the new expenses process.'},{who:'You',item:'walkthrough'}], targets:['day','walkthrough'] },
    deadline: { title: 'A change of plan', subtitle: 'Bring up a concern about a deadline', lines: [{who:'Alex',text:'We’d like to launch on Friday.'},{who:'You',item:'concern'},{who:'Alex',text:'Of course. What would you suggest?'},{who:'You',text:'Could we move it to next week?'}], targets:['concern'] }
  };
  const defaults = () => ({screen:'home',tab:'home',index:0,phase:'speak',help:false,explained:false,queue:[],results:[],item:'day',dialogue:'meeting',mode:'daily',filter:'all',query:''});
  const states = {focus:defaults(),context:defaults()};
  const settings = {focus:{phraseSize:30,context:false},context:{phraseSize:30,context:true}};
  function restore(saved) {
    if (!saved || saved.privateContent?.version !== 1) return;
    ['focus','context'].forEach(key => {
      const next = saved.privateContent.states?.[key];
      if (next && ['home','library','dialogues','detail','dialogue','session','summary'].includes(next.screen)) {
        states[key] = {...defaults(),...next};
        if (!Array.isArray(next.queue) || next.queue.some(e => !items[e.item])) states[key]=defaults();
        if (states[key].screen==='session' && (!states[key].queue.length || !states[key].queue[states[key].index])) states[key]=defaults();
      }
    });
  }
  restore(window.openai?.widgetState);
  function persist(key) {
    const s=states[key];
    window.openai?.setWidgetState?.({modelContent:{app:'Phrase Gym',layout:key==='focus'?'Focus':'In context',screen:s.screen,exercise:s.queue[s.index]?.item,phase:s.phase,previewOnly:true},privateContent:{version:1,states}})?.catch(() => {});
  }
  const button = (label,action,classes='pg-btn pg-primary pg-block',extra='') => `<button type="button" class="${classes} cursor-interaction" data-action="${action}" ${extra}>${label}</button>`;
  function nav(active) {
    return `<nav class="pg-nav" aria-label="Main navigation">${[['home','Practice','circle-play'],['library','Phrases','layers'],['dialogues','Dialogues','messages-square']].map(([key,label,glyph])=>button(`<span class="pg-nav-icon">${icon(glyph)}</span>${label}`,'nav','',`data-destination="${key}" ${active===key?'aria-current="page"':''}`)).join('')}</nav>`;
  }
  function chrome() { return `<header class="pg-chrome"><div class="pg-wordmark"><span class="pg-logo">${icon('quote')}</span>Phrase Gym</div><span class="pg-language">English</span></header>`; }
  function row(id,preview=false) {
    const p=items[id];
    return button(`<span class="pg-item-symbol">${icon(p.type==='Phrase'?'quote':'whole-word')}</span><span class="pg-row-text"><span class="pg-row-title">${escape(preview?p.label:p.text)}</span><span class="pg-row-sub">${p.source} · ${p.type}</span></span><span class="pg-badge">${p.status}</span>`,'detail','pg-row',`data-item="${id}"`);
  }
  function home(key) {
    return `${chrome()}<main class="pg-content"><div class="pg-home-heading"><div class="pg-overline">A few minutes, every day</div><h1>Make it come<br>naturally.</h1><p class="pg-subtitle">Practise the phrases you want to reach for.</p></div><section class="pg-session-card"><div class="pg-overline">Today’s practice</div><h2>${key==='context'?'A little<br>back-and-forth.':'Small talk.<br>Speaking up.'}</h2><p>2 to review · 1 to learn<br>About 4 minutes</p>${button(`Start practice ${icon('arrow-right')}`,'start')}</section><div class="pg-section-title"><h3>In this session</h3></div><div class="pg-list">${row('day',true)}${row('concern',true)}${row('walkthrough',true)}</div></main>${nav('home')}`;
  }
  function library(s) {
    const filtered=Object.keys(items).filter(id=>(s.filter==='all'||items[id].status.toLowerCase()===s.filter)&&items[id].text.toLowerCase().includes(s.query.toLowerCase()));
    return `${chrome()}<main class="pg-content"><div class="pg-home-heading"><div class="pg-overline">Your collection</div><h1>Words to keep.</h1><p class="pg-subtitle">Phrases, useful chunks and the places you use them.</p></div><label class="pg-sr" for="search-${s.key}">Find a phrase</label><input class="pg-inline-search" id="search-${s.key}" type="search" placeholder="Find a phrase…" value="${escape(s.query)}"><div class="pg-filter-row">${[['all','All'],['due','Due'],['new','New']].map(([key,label])=>button(label,'filter','pg-filter',`data-filter="${key}" aria-pressed="${s.filter===key}"`)).join('')}</div><div class="pg-list" data-phrase-list>${filtered.length?filtered.map(id=>row(id)).join(''):'<p class="pg-subtitle">No phrases match this search.</p>'}</div></main>${nav('library')}`;
  }
  function detail(s) {
    const p=items[s.item];
    return `<header class="pg-session-header">${button(icon('arrow-left'),'back','pg-icon-btn','aria-label="Back"')}<span class="pg-small">${p.source}</span><span class="pg-badge">${p.type}</span></header><main class="pg-content"><div class="pg-detail-phrase"><div class="pg-overline">${p.label}</div><p class="pg-phrase">${escape(p.text)}</p><div class="pg-action-row">${button(`${icon('volume-2')} Listen`,'audio','pg-plain','disabled aria-label="Listen to model audio, unavailable in this preview"')}</div></div><div class="pg-detail-line"><span>When to use it</span><p>${p.purpose}</p></div><div class="pg-detail-line"><span>Meaning & usage</span><p>${p.explanation}</p></div><div class="pg-detail-line"><span>Practice</span><p>Recall the phrase with a cue, then say it in a short dialogue.</p></div><div class="pg-actions">${button('Practise this expression','practice-item')}${button(`${icon('messages-square')} See it in a dialogue`,'related-dialogue','pg-btn pg-block')}</div></main>${nav('library')}`;
  }
  function dialogueList() {
    return `${chrome()}<main class="pg-content"><div class="pg-home-heading"><div class="pg-overline">Put phrases to work</div><h1>Take your part.</h1><p class="pg-subtitle">Learn a short exchange. Then rehearse your lines.</p></div><div class="pg-list">${Object.entries(dialogues).map(([id,d])=>button(`<span class="pg-item-symbol">${icon('messages-square')}</span><span class="pg-row-text"><span class="pg-row-title">${d.title}</span><span class="pg-row-sub">${d.subtitle}<br>${d.targets.length} target expression${d.targets.length>1?'s':''}</span></span>${icon('chevron-right')}`,'dialogue','pg-row',`data-dialogue="${id}"`)).join('')}</div></main>${nav('dialogues')}`;
  }
  function dialogue(s) {
    const d=dialogues[s.dialogue];
    return `<header class="pg-session-header">${button(icon('arrow-left'),'back','pg-icon-btn','aria-label="Back to dialogues"')}<span class="pg-small">Learn the exchange</span><span></span></header><main class="pg-content"><h2>${d.title}</h2><p class="pg-subtitle">You’ll practise the marked expressions.</p><div class="pg-transcript">${d.lines.map(line=>`<div class="pg-turn ${line.who==='You'?'pg-you':''}"><div class="pg-speaker">${line.who}${line.item?' · target expression':''}</div><p class="${line.item?'pg-recalled':''}">${escape(line.item?items[line.item].text:line.text)}</p></div>`).join('')}</div>${button('Rehearse my lines','start-dialogue')}</main>${nav('dialogues')}`;
  }
  function masked(item,mask,full,highlight) {
    const parts=items[item].masks[mask||0];
    return `${escape(parts[0])}${full?`<span class="${highlight?'pg-recalled':''}">${escape(parts[1])}</span>`:`<span class="pg-hidden" role="img" aria-label="Hidden phrase chunk"></span>`}${escape(parts[2])}`;
  }
  function session(s,key) {
    const q=s.queue[s.index], p=items[q.item];
    const isLearn=s.phase==='learn', isCheck=s.phase==='check', isRepair=s.phase==='repair', isRead=s.phase==='read';
    const full=isLearn||isCheck||isRepair||isRead||s.phase==='alternative'||s.help;
    const showContext=settings[key].context||s.mode==='dialogue';
    const partner=q.partner||p.partner;
    let actions='';
    if(isRead) return `<header class="pg-session-header">${button(icon('x'),'exit','pg-icon-btn','aria-label="Leave practice"')}<span class="pg-small">Finish the exchange</span><span></span></header><main class="pg-exercise"><div class="pg-purpose"><div class="pg-overline">Read your next line</div><h2>Suggest a different date.</h2></div><div class="pg-partner"><div class="pg-speaker">Alex</div><p>“Of course. What would you suggest?”</p></div><section class="pg-phrase-card"><div class="pg-context-label">Your supporting line</div><p class="pg-phrase">Could we move it to next week?</p></section><p class="pg-instruction">Read this line aloud to finish the dialogue.</p><div class="pg-actions">${button('Finish dialogue','finish-dialogue')}</div></main>`;
    if(isRepair) actions=`<p class="pg-instruction">Read the complete phrase aloud once more.</p><div class="pg-notice">Take your time. Keep the whole phrase together.</div><div class="pg-actions">${button('I’ve repeated it','repaired')}${button(`${icon('volume-2')} Listen to the model`,'audio','pg-plain','disabled')}</div>`;
    else if(s.phase==='alternative') actions=`<p class="pg-instruction">Another expression may work here.</p><div class="pg-notice">Practise the expression above, or flag the cue if it did not make the target clear.</div><div class="pg-actions">${button('Practise this expression','again')}${button('The cue was unclear','unclear','pg-btn pg-block')}</div>`;
    else if(isLearn) actions=`<p class="pg-instruction">Read it. Hear it. Say it aloud.</p><div class="pg-actions">${button('Try with a cue','try-cue')}${button(`${icon('volume-2')} Listen to the model`,'audio','pg-plain','disabled')}</div>`;
    else if(isCheck) actions=`<p class="pg-feedback-label">Did you say the complete expression?</p>${s.help?'<div class="pg-notice">You used the full phrase. You’ll get another chance to recall it.</div>':''}<div class="pg-actions">${button(`${icon('check')} ${s.help?'Said it with the model':'Matched the phrase'}`,'matched')}${button('I need another try','again','pg-btn pg-block')}${button('I used different wording','alternative','pg-plain')}${button(`${icon('volume-2')} Listen to the model`,'audio','pg-plain','disabled')}</div>`;
    else actions=`<p class="pg-instruction">Say the <strong>whole phrase</strong> aloud.</p><div class="pg-action-row">${button(s.help?'Full phrase shown':'Show the phrase','help','pg-plain',s.help?'disabled':'')}${button('Meaning','meaning','pg-plain')}</div>${s.explained?`<div class="pg-notice">${p.explanation}</div>`:''}<div class="pg-actions">${button(`I’ve said it ${icon('arrow-right')}`,'check')}<p class="pg-small" style="text-align:center">Then compare with the model.</p></div>`;
    return `<header class="pg-session-header">${button(icon('x'),'exit','pg-icon-btn','aria-label="Leave practice"')}<span class="pg-small">${s.mode==='dialogue'?'Dialogue practice':'Today’s practice'}</span><span class="pg-small">${s.index+1} / ${s.queue.length}</span></header><div class="pg-track" role="progressbar" aria-label="Session progress" aria-valuenow="${s.index}" aria-valuemin="0" aria-valuemax="${s.queue.length}"><span style="width:${s.index/s.queue.length*100}%"></span></div><main class="pg-exercise"><div class="pg-purpose"><div class="pg-overline">${s.phase==='alternative'?'Different wording':isRepair?'Repeat with the model':isLearn?'New expression':isCheck?'Check your phrase':q.fresh?'Practise the expression':'Recall your expression'}</div><h2>${p.purpose}</h2></div>${showContext?`<div class="pg-partner"><div class="pg-speaker">${icon('volume-2')} Alex</div><p>“${escape(partner)}”</p></div>`:''}<section class="pg-phrase-card" aria-label="${full?'Complete expression':'Phrase recall cue'}"><div class="pg-context-label">${isCheck||isRepair?'The expression':isLearn?'Your new expression':showContext?'Your line':'Your cue'}</div><p class="pg-phrase">${masked(q.item,q.mask,full,isCheck)}</p></section>${actions}</main>`;
  }
  function summary(s) {
    const ids=[...new Set(s.results.map(r=>r.item))];
    const tricky=ids.filter(id=>s.results.some(r=>r.item===id&&!r.unclear&&(r.help||!r.matched)));
    const describe=id=>s.results.some(r=>r.item===id&&r.unclear)?'Cue flagged for review':s.results.some(r=>r.item===id&&!r.unclear&&(r.help||!r.matched))?'Needs another recall':s.results.some(r=>r.item===id&&r.fresh)?'Introduced and practised with a cue':'Recalled with a cue';
    return `${chrome()}<main class="pg-content"><div class="pg-summary-icon">${icon('check')}</div><div class="pg-overline">Session complete</div><h1>That’s practice<br>in the bank.</h1><p class="pg-subtitle">${ids.length} expression${ids.length!==1?'s':''} practised.<br>A small step toward easier conversations.</p><div class="pg-summary-list">${ids.map(id=>`<div class="pg-summary-line"><span class="pg-dot"></span><div>${escape(items[id].text)}<p class="pg-small">${describe(id)}</p></div></div>`).join('')}</div><div class="pg-actions">${tricky.length?button('Revisit the tricky ones','retry-tricky'):button('Try a short dialogue','to-dialogues')}${button('Back to practice','home','pg-btn pg-block')}</div></main>`;
  }
  function render(key) {
    const app=root.querySelector(`#pg-${key}`),s=states[key];
    s.key=key;
    app.style.setProperty('--pg-phrase-size',settings[key].phraseSize+'px');
    const views={home:()=>home(key),library:()=>library(s),detail:()=>detail(s),dialogues:()=>dialogueList(),dialogue:()=>dialogue(s),session:()=>session(s,key),summary:()=>summary(s)};
    app.innerHTML=views[s.screen]()+`<div class="pg-preview-note">Design preview · audio is not connected</div><span class="pg-sr" role="status" aria-live="polite">${s.screen==='session'?`${s.phase}, exercise ${s.index+1} of ${s.queue.length}`:s.screen}</span>`;
    if(globalThis.lucide) lucide.createIcons({attrs:{width:18,height:18}});
  }
  function begin(s,queue,mode='daily') {
    Object.assign(s,{screen:'session',queue,index:0,mode,results:[],help:false,explained:false,alternative:false,phase:queue[0].fresh?'learn':'speak'});
  }
  function advance(s) {
    if(s.mode==='dialogue'&&s.dialogue==='deadline'&&s.phase!=='read'&&s.index===s.queue.length-1){s.phase='read';return;}
    s.index++;s.help=false;s.explained=false;s.alternative=false;
    if(s.index>=s.queue.length)s.screen='summary';
    else s.phase=s.queue[s.index].fresh?'learn':'speak';
  }
  ['focus','context'].forEach(key=>{
    const app=root.querySelector(`#pg-${key}`);
    app.addEventListener('input',event=>{
      if(!event.target.matches('.pg-inline-search')) return;
      const s=states[key];s.query=event.target.value;
      const ids=Object.keys(items).filter(id=>(s.filter==='all'||items[id].status.toLowerCase()===s.filter)&&items[id].text.toLowerCase().includes(s.query.toLowerCase()));
      app.querySelector('[data-phrase-list]').innerHTML=ids.length?ids.map(id=>row(id)).join(''):'<p class="pg-subtitle">No phrases match this search.</p>';
      if(globalThis.lucide)lucide.createIcons({attrs:{width:18,height:18}});
      persist(key);
    });
    app.addEventListener('click',event=>{
      const target=event.target.closest('button[data-action]');if(!target||target.disabled)return;
      const action=target.dataset.action,s=states[key];
      if(action==='nav'){s.screen=target.dataset.destination;s.tab=s.screen;}
      if(action==='home'||action==='exit'){s.screen='home';s.tab='home';}
      if(action==='start')begin(s,[{item:'day',mask:0},{item:'walkthrough',mask:0,fresh:true},{item:'concern',mask:0},{item:'day',mask:1}]);
      if(action==='detail'){s.item=target.dataset.item;s.screen='detail';}
      if(action==='filter')s.filter=target.dataset.filter;
      if(action==='back')s.screen=s.screen==='dialogue'?'dialogues':s.tab;
      if(action==='practice-item')begin(s,[{item:s.item,mask:0,fresh:items[s.item].status==='New'}],'single');
      if(action==='related-dialogue'){s.dialogue=s.item==='concern'?'deadline':'meeting';s.screen='dialogue';}
      if(action==='dialogue'){s.dialogue=target.dataset.dialogue;s.screen='dialogue';}
      if(action==='to-dialogues')s.screen='dialogues';
      if(action==='start-dialogue'){
        const d=dialogues[s.dialogue],queue=[];
        d.lines.forEach((line,i)=>{if(line.item)queue.push({item:line.item,mask:0,partner:d.lines[i-1]?.text});});
        begin(s,queue,'dialogue');
      }
      if(action==='try-cue')s.phase='speak';
      if(action==='help')s.help=true;
      if(action==='meaning')s.explained=!s.explained;
      if(action==='check')s.phase='check';
      if(action==='alternative'){s.phase='alternative';s.alternative=true;}
      if(action==='unclear'){s.results.push({item:s.queue[s.index].item,unclear:true,matched:false});advance(s);}
      if(action==='again')s.phase='repair';
      if(action==='matched'||action==='repaired'){
        const q=s.queue[s.index];s.results.push({item:q.item,help:s.help,matched:action==='matched',fresh:!!q.fresh});
        advance(s);
      }
      if(action==='finish-dialogue')advance(s);
      if(action==='retry-tricky'){
        const ids=[...new Set(s.results.filter(r=>!r.unclear&&(r.help||!r.matched)).map(r=>r.item))];
        begin(s,ids.map(item=>({item,mask:items[item].masks.length>1?1:0})),'review');
      }
      render(key);persist(key);
    });
    render(key);
    if(globalThis.Tweak){
      const tweak=new Tweak({container:app,onChange:()=>render(key)});
      tweak.addSlider(settings[key],'phraseSize',{label:'Phrase size',min:26,max:34,step:1,unit:'px'});
      tweak.addToggle(settings[key],'context',{label:'Show partner’s line'});
    }
  });
  window.addEventListener('openai:set_globals',event=>{
    if(event.detail?.globals?.widgetState){restore(event.detail.globals.widgetState);render('focus');render('context');}
  });
})();

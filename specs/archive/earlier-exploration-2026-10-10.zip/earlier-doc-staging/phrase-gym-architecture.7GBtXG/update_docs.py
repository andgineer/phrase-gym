from pathlib import Path
import difflib
import hashlib
import json
import re
import sys

stage=Path(__file__).resolve().parent
root=Path('/Users/andrei_sorokin2/projects/phrase-shadowing')
files={
    'CLAUDE.md':'CLAUDE.md',
    'README.md':'README.md',
    'spec/functional-description.md':'functional-description.md',
    'spec/decision-name-and-design.md':'decision-name-and-design.md',
    'spec/plan/functionality-discussion.md':'functionality-discussion.md',
    'spec/design/interaction-design.md':'interaction-design.md',
    'spec/architecture.md':'architecture.md',
    'spec/architecture/learning-engine.md':'learning-engine.md',
    'spec/architecture/data-contracts.md':'data-contracts.md',
    'spec/plan/implementation-plan.md':'implementation-plan.md',
    'spec/plan/01-prototyping.md':'01-prototyping.md',
    'spec/plan/02-core-implementation.md':'02-core-implementation.md',
    'spec/plan/03-content-and-integrations.md':'03-content-and-integrations.md',
    'spec/plan/04-validation-and-release.md':'04-validation-and-release.md',
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None

def replace_once(text, old, new):
    if text.count(old)!=1: raise SystemExit('Expected source changed: '+old)
    return text.replace(old,new,1)

mode=sys.argv[1]
if mode=='prepare':
    f=(root/'spec/functional-description.md').read_text()
    f=replace_once(f,'Updated 2026-10-10. **The scope and core drilling decisions are accepted; the complete feature set and first-version boundary remain a draft.** The [drilling decision](decision-targeted-drilling.md) is authoritative for the learning flow. [Open questions](plan/functionality-discussion.md) track what still needs agreement.',
      'Updated 2026-10-11. **Draft supporting scope. The agreed baseline is [targeted drilling](decision-targeted-drilling.md); there is no accepted Phrase Gym prototype or implementation.** Other features below are candidates to validate through [prototyping](plan/01-prototyping.md), not additional approved requirements. See the [architecture](architecture.md) and [implementation roadmap](plan/implementation-plan.md) for the proposed work.')
    f=replace_once(f,'It replaces the existing phrase prototype and, eventually, echo-words\' Anki output.','It is intended to provide its own drilling and review workflow, with a future intake from echo-words.')
    f=replace_once(f,'The user authorized design exploration on 2026-10-10; see the [interaction design](design/interaction-design.md). Remaining functional choices stay open during design. Deployment remains a later phase.','The next implementation phase is [prototyping](plan/01-prototyping.md). Architecture and implementation plans are recommendations; remaining functional choices are resolved through concrete prototypes and pilot evidence. Deployment remains a later phase.')
    (stage/'functional-description.md').write_text(f)
    r=(root/'README.md').read_text()
    r=replace_once(r,'# phrase-shadowing','# phrase-shadowing — Phrase Gym workspace')
    r=replace_once(r,'This README covers the current prototype and its tooling. A replacement app is being designed — start with `CLAUDE.md` and `spec/`.','This README describes legacy source tooling, not an accepted Phrase Gym prototype. The agreed baseline is [targeted drilling](spec/decision-targeted-drilling.md). Start new work with the [architecture](spec/architecture.md) and [implementation plan](spec/plan/implementation-plan.md), which includes prototyping as its first phase. Legacy file and publishing instructions below do not establish the current state of a live app or progress to migrate.')
    (stage/'README.md').write_text(r)
    protected=['spec/decision-targeted-drilling.md','spec/research-memorizing-phrases.md','index.html','phrases.py']
    manifest={'files':{rel:sha(root/rel) for rel in files},'protected':{rel:sha(root/rel) for rel in protected},'symlink':str((root/'AGENTS.md').readlink())}
    (stage/'manifest.json').write_text(json.dumps(manifest,indent=2))
    for rel,name in files.items():
        old=(root/rel).read_text() if (root/rel).exists() else ''
        new=(stage/name).read_text()
        (stage/(name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=rel,tofile=rel)))
        print(f'{rel}: {len(old.splitlines())} -> {len(new.splitlines())} lines')
elif mode=='apply':
    manifest=json.loads((stage/'manifest.json').read_text())
    for rel in files:
        if sha(root/rel)!=manifest['files'][rel]: raise SystemExit('Concurrent change; nothing written: '+rel)
    for rel,name in files.items():
        p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((stage/name).read_bytes())
        print('Saved '+rel)
elif mode=='verify':
    manifest=json.loads((stage/'manifest.json').read_text())
    for rel,name in files.items():
        assert (root/rel).read_bytes()==(stage/name).read_bytes(),rel
    for rel,digest in manifest['protected'].items(): assert sha(root/rel)==digest,rel
    assert (root/'AGENTS.md').is_symlink() and str((root/'AGENTS.md').readlink())==manifest['symlink']
    count=0
    for rel in files:
        p=root/rel
        text=p.read_text()
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
            if '://' in target: continue
            file,_,anchor=target.partition('#')
            linked=(p.parent/file) if file else p
            assert linked.exists(),f'{rel}: {target}'
            if anchor:
                headings=re.findall(r'^#+ (.+)$',linked.read_text(),flags=re.M)
                slugs=[re.sub(r'[^\w\- ]','',heading.lower()).replace(' ','-') for heading in headings]
                assert anchor in slugs,f'{rel}: missing anchor {target}'
            count+=1
        for data in re.findall(r'```json\n(.*?)\n```',text,flags=re.S):json.loads(data)
    print(f'Verified {len(files)} documents, {count} local links/anchors and JSON examples.')
    print('Agreed drilling decision, research record, legacy code and AGENTS symlink unchanged.')
else: raise SystemExit('Use prepare, apply or verify')

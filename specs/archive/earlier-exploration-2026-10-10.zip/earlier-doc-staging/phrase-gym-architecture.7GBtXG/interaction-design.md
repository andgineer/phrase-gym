# Phrase Gym — interaction design to produce

Updated 2026-10-11. **No app prototype or approved interaction design exists.** Earlier conversation sketches are exploratory material only. The [targeted-drilling decision](../decision-targeted-drilling.md) is the baseline; follow [P1 prototyping](../plan/01-prototyping.md) to create and validate the design.

The prototype must make each step concrete: what the learner sees/hears, the whole phrase they should say, what help reveals, how comparison works and what happens after success, difficulty, different wording or an unclear cue.

Produce and review:

- new-expression introduction, phrase recall and word/frame practice;
- sufficient phrase-specific cues and useful changes to the hidden chunks;
- full-phrase responses, model comparison, repair and delayed return;
- specific dialogue rehearsal with supporting lines and a difficult-turn detour;
- pause/resume and recording/permission/interruption states;
- a clear result that distinguishes support from independent recall;
- navigation to practice, content and dialogues, with no requirement to inherit earlier labels or layouts.

Compare a focused phrase view and a context-visible view if useful. Mobile-first PWA, optional recording and the broader navigation are architecture/design recommendations pending the prototype; no previous selected carousel state constitutes user approval.

The output of this work will be a runnable prototype, recorded user feedback, actual-device findings and revised design decisions. The [roadmap](../plan/implementation-plan.md) keeps that work ahead of production implementation.

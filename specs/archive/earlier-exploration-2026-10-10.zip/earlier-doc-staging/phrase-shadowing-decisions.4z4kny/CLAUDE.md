# phrase-shadowing — agent instructions

`AGENTS.md` is a symlink to this file — one document, whichever name the tool looks for.

This folder holds two things:

1. **A working prototype in daily use** — "Английское эхо", a phrase trainer published as a claude.ai artifact: https://claude.ai/artifact/Jwe4YpVMthy8UjerkdEKY2. `phrases.py` builds it from lesson notes in the Obsidian vault into `index.html`; `README.md` documents that tooling. The user practises with it and has progress stored in it — do not break it.
2. **A new app being designed** — a trainer for ready-made language (fixed phrases and words in context, any language) that is meant to replace both the prototype and echo-words' Anki output. The work runs in three phases: **functionality → design → deploy**. It is in phase 1. Do not start design or hosting until the user settles the functionality.

## Pick up here

Read in this order:

1. `spec/plan/functionality-discussion.md` — current state, remaining functional choices and deferred work.
2. `spec/decision-targeted-drilling.md` — accepted scope and drilling decisions, including phrase-specific cues and varying the hidden chunks. These supersede earlier brainstorms.
3. `spec/functional-description.md` — consolidated app behaviour; the complete feature set and first-version boundary remain a draft.
4. `spec/research-memorizing-phrases.md` — focused primary evidence and its limits; distinguish findings from product decisions.
5. `discussion/` — raw session history (2026-10-08…10), only for details the current documents do not cover. It is not the active specification.

## Working with the user

- Reply in English. Vault notes keep Russian titles, folder names and prose; learning material inside them stays in the target language.
- Every decision put to the user follows the global rule: facts, each option explained by what the user sees, a comparison table of concrete situations, one recommendation phrased so they can answer "yes".
- Learning content is target-language only. Translations and explanations appear only when the user asks for them (they are B2 in English and said Russian translations distract them). For weaker languages (Serbian, German, …) on-demand translation matters more.
- Drill known expressions and words in useful phrases and specific dialogues. Open-ended AI conversation and free role-play are out of scope, including as a later direction. AI may prepare material and facilitate targeted practice.
- Cue each target with enough meaningful material to distinguish the intended expression in context. Choose useful chunks from anywhere in the phrase; never mechanically reveal its beginning. Different repetitions may hide different chunks. The learner says the whole phrase. Random gaps and first-letter puzzles remain rejected.
- A broad situation prompt cannot demand one exact answer. Do not penalize a valid alternative when the prompt is ambiguous, or count visible-model repetition as independent recall. See the accepted decision for answer handling and one schedule per target.
- Code, scripts and tooling live under `~/projects/`, never in the vault.
- The vault `~/obsidian/kb` is a local Obsidian working copy synced by obsidian-git: never commit, push, switch branches or `git mv` there; plain file edits and `mv` only.
- This folder is not a git repository yet; do not init or commit unless asked.

## Related places

- Vault phrase notes: `~/obsidian/kb/languages/english/фразы/` — hub `фразы.md`, one note per lesson, audio in `_assets/` (actor recordings, and neural-voice clips with a `-tts` suffix).
- Earlier small-talk Anki cards: `~/obsidian/kb/languages/english/vocabulary/small-talk/`.
- echo-words: `~/projects/echo-words` — FastAPI + Vue PWA on an Oracle Cloud free-tier VM, tailnet-only; analyses a word with free LLMs (llmbroker), voices it (edge-tts / Piper) and adds four Anki cards per sense. The new app should receive items from echo-words instead of Anki.
- EPAM course "English for Negotiations B1+/B2/B2+" on elearn.epam.com: one mini-course per lesson; read through Claude in Chrome (EPAM SSO fails in the built-in browser). The user is enrolled in lessons 1–2 only.

# Functionality — current decisions and remaining work

Updated 2026-10-10. Phase 1: **functionality → design → deploy**.

## Current documents

- [Accepted drilling decisions](../decision-targeted-drilling.md): product scope, phrase-specific cues, rotating hidden chunks, complete spoken responses, answer handling, one schedule per target and AI's role.
- [Functional description](../functional-description.md): consolidated app behaviour; supporting features and first-version scope are still a draft.
- [Research record](../research-memorizing-phrases.md): relevant primary evidence and the boundary between findings and product decisions.

These documents replace the earlier option lists and exercise brainstorm. The raw discussion export remains in `../../discussion/` for historical details, not as the active specification.

## Settled direction

Build a dedicated trainer for selected words in phrases and specific expressions in specific dialogues, toward automatic use in the intended situations. AI may prepare material and facilitate drills. Open-ended AI conversation and free role-play are excluded from the product.

The learner recalls a known target with enough phrase-specific material to distinguish the intended expression. Cues can retain any useful part of the phrase; they do not mechanically reveal its beginning. Different repetitions can hide different meaningful chunks. The response is the complete phrase.

Sources are vault phrase banks and echo-words. One review schedule per learning target addresses the unwanted repeated reviews caused by separately scheduled Anki cards. Recording comparison, contextual help and help with difficult items remain desired capabilities.

## Remaining functional choices

| Question | What still needs deciding |
|---|---|
| First-version scope | Vault phrases first, or vault phrases and echo-words intake together; which supporting features and languages ship initially. The earlier recommendation was phrases first using the prepared material; it has not been accepted. Both words and phrases remain in the product scope. |
| Cue adaptation | How candidate cues are checked, when to change the hidden chunks, and when to add or reduce support. The principle is accepted; no rotation frequency or fixed level ladder is agreed. |
| Review and progress | How accuracy, support and hesitation affect the single target schedule; what demonstrates improvement and when an item is ready for less support. |
| Assessment and hands-free use | Whether automatic speech feedback ships initially; how to handle recognition uncertainty and how the learner requests help or reports an outcome without the screen. |

Next: work through concrete sessions using the accepted cue rules, resolve these choices, and obtain agreement on the complete functional description. Do not reopen excluded product directions.

## Deferred work

- **Additional course material:** EPAM lessons 1–2 are enrolled; lessons 3–14 are not. Enrolment has not been authorized. Revisit only when gathering more sources; see the [prototype tooling instructions](../../README.md).
- **Existing prototype:** remains in daily use, with stored progress. Its interface changes and replacement are separate work; preserve it during planning.
- **Deployment:** the user named the existing Oracle Cloud VM and an always-on laptop reached over Tailscale as candidates. echo-words currently uses a 1 GB x86_64 Oracle micro VM. Decide hosting in phase 3 and recheck constraints then; earlier artifact limits are not architecture decisions for the new app.

from pathlib import Path
import difflib
import hashlib
import json
import sys

STAGE = Path(__file__).resolve().parent
ROOT = Path('/Users/andrei_sorokin2/projects/phrase-shadowing')
FILES = {
    'spec/decision-targeted-drilling.md': 'decision-targeted-drilling.md',
    'spec/functional-description.md': 'functional-description.md',
    'spec/plan/functionality-discussion.md': 'functionality-discussion.md',
    'spec/research-memorizing-phrases.md': 'research-memorizing-phrases.md',
    'CLAUDE.md': 'CLAUDE.md',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None

mode = sys.argv[1]
if mode == 'prepare':
    original = (ROOT / 'CLAUDE.md').read_text()
    old_reading = '''1. `spec/plan/functionality-discussion.md` — where the discussion stands: what the user has settled, what they rejected and why, the open decisions with recommendations, facts already checked for later phases.
2. `spec/functional-description.md` — the draft concept of the new app. A draft for discussion, not accepted yet.
3. `spec/research-memorizing-phrases.md` — the research the concept rests on, with evidence strength and sources.
4. `discussion/` — a raw export of the session (2026-10-08…10) that produced all this. Only for details the documents above do not cover.'''
    new_reading = '''1. `spec/plan/functionality-discussion.md` — current state, remaining functional choices and deferred work.
2. `spec/decision-targeted-drilling.md` — accepted scope and drilling decisions, including phrase-specific cues and varying the hidden chunks. These supersede earlier brainstorms.
3. `spec/functional-description.md` — consolidated app behaviour; the complete feature set and first-version boundary remain a draft.
4. `spec/research-memorizing-phrases.md` — focused primary evidence and its limits; distinguish findings from product decisions.
5. `discussion/` — raw session history (2026-10-08…10), only for details the current documents do not cover. It is not the active specification.'''
    old_rule = '- The user rejects puzzle-like exercises: first-letter hints for whole phrases, random gap-fills, scene descriptions in place of the phrase\'s purpose. Practice must look like real use: hear a trigger, say the phrase aloud.'
    new_rule = '''- Drill known expressions and words in useful phrases and specific dialogues. Open-ended AI conversation and free role-play are out of scope, including as a later direction. AI may prepare material and facilitate targeted practice.
- Cue each target with enough meaningful material to distinguish the intended expression in context. Choose useful chunks from anywhere in the phrase; never mechanically reveal its beginning. Different repetitions may hide different chunks. The learner says the whole phrase. Random gaps and first-letter puzzles remain rejected.
- A broad situation prompt cannot demand one exact answer. Do not penalize a valid alternative when the prompt is ambiguous, or count visible-model repetition as independent recall. See the accepted decision for answer handling and one schedule per target.'''
    if original.count(old_reading) != 1 or original.count(old_rule) != 1:
        raise SystemExit('Expected instruction text changed; inspect before preparing.')
    (STAGE / 'CLAUDE.md').write_text(original.replace(old_reading, new_reading).replace(old_rule, new_rule))
    manifest = {rel: digest(ROOT / rel) for rel in FILES}
    protected = ['AGENTS.md', 'README.md', 'index.html', 'phrases.py', 'discussion/session-2026-10-08-to-10.zip']
    manifest['_protected'] = {rel: digest(ROOT / rel) for rel in protected if rel != 'AGENTS.md'}
    manifest['_symlink'] = str((ROOT / 'AGENTS.md').readlink())
    (STAGE / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    for rel, staged in FILES.items():
        path = ROOT / rel
        old = path.read_text() if path.exists() else ''
        new = (STAGE / staged).read_text()
        (STAGE / (staged + '.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile=rel, tofile=rel)))
        print(f'{rel}: {len(old.splitlines())} -> {len(new.splitlines())} lines')
elif mode == 'apply':
    manifest = json.loads((STAGE / 'manifest.json').read_text())
    for rel in FILES:
        if digest(ROOT / rel) != manifest[rel]:
            raise SystemExit(f'Concurrent change in {rel}; nothing written.')
    for rel, staged in FILES.items():
        (ROOT / rel).write_bytes((STAGE / staged).read_bytes())
        print(f'Updated {rel}')
elif mode == 'verify':
    manifest = json.loads((STAGE / 'manifest.json').read_text())
    for rel, staged in FILES.items():
        assert (ROOT / rel).read_bytes() == (STAGE / staged).read_bytes(), rel
    for rel, sha in manifest['_protected'].items():
        assert digest(ROOT / rel) == sha, f'Unexpected change: {rel}'
    assert (ROOT / 'AGENTS.md').is_symlink()
    assert str((ROOT / 'AGENTS.md').readlink()) == manifest['_symlink']
    import re
    links = 0
    for rel in FILES:
        path = ROOT / rel
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', path.read_text()):
            if '://' in target:
                continue
            assert (path.parent / target.split('#')[0]).exists(), f'Broken link in {rel}: {target}'
            links += 1
    print(f'Verified 5 documents, {links} local links, protected files and AGENTS.md symlink.')
else:
    raise SystemExit('Use prepare, apply or verify.')
